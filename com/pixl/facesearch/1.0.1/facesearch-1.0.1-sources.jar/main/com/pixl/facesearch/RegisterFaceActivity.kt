package com.pixl.facesearch

interface FaceSearchResultCallback {
    fun onFaceRegistered(response: String, faceImage: String)
    fun onFaceDetected(response: String ,faceImage: String?, isFaceMatching: Boolean)
    fun onSpoofDetected(faceImage: String?)

    fun onNewUserRegistered(image: String, name: String, email: String, phoneNumber: String, organization: String)
}


interface FaceMatchResultCallback {
    fun onFaceDetected(response: String ,faceImage: String?, faceImage2: String?, isFaceMatching: Boolean)
    fun onErroDetected(response: String, faceImage: String?)
}

//
//class RegisterFaceActivity : AppCompatActivity() {
//
//    private var imageCapture: ImageCapture? = null
//    private lateinit var cameraExecutor: ExecutorService
//    private lateinit var viewFinder: PreviewView
//    private lateinit var faceLandmarker: FaceLandmarker
//
//    // Layouts
//    private lateinit var captureView: ConstraintLayout
//    private lateinit var registerView: ScrollView
//    private lateinit var profileImage: ImageView
//    private lateinit var captureLoader: ProgressBar
//    private lateinit var captureBtn: ImageButton // Keep reference to disable it
//
//    // Inputs
//    private lateinit var nameField: TextInputLayout
//    private lateinit var emailField: TextInputLayout
//    private lateinit var phoneNumberField: TextInputLayout
//    private lateinit var organizationField: TextInputLayout
//    private lateinit var submitButton: Button
//    private lateinit var retakeButton: TextView
//
//    private var faceImageBase64 : String  = ""
//
//    // Camera State
//    private var cameraSelector: CameraSelector = CameraSelector.DEFAULT_FRONT_CAMERA
//
//    companion object {
//        private const val TAG = "CameraXApp"
//        private val REQUIRED_PERMISSIONS =
//            mutableListOf(Manifest.permission.CAMERA).apply {
//                if (Build.VERSION.SDK_INT <= Build.VERSION_CODES.P) {
//                    add(Manifest.permission.WRITE_EXTERNAL_STORAGE)
//                }
//            }.toTypedArray()
//
//        private var onFaceSearchResult: WeakReference<FaceSearchResultCallback>? = null
//
//        fun setFaceSearchResultCallback(callback: FaceSearchResultCallback) {
//            onFaceSearchResult = WeakReference(callback)
//        }
//    }
//
//    override fun onCreate(savedInstanceState: Bundle?) {
//        super.onCreate(savedInstanceState)
//        enableEdgeToEdge()
//        setContentView(R.layout.activity_register_face)
//
//        // 1. Bind Views
//        viewFinder = findViewById(R.id.viewFinder)
//        captureView = findViewById(R.id.captureView)
//        registerView = findViewById(R.id.registerView)
//        profileImage = findViewById(R.id.profileImage)
//        captureLoader = findViewById(R.id.captureLoader) // Bind ProgressBar
//
//        captureBtn = findViewById(R.id.btnCapture)
////        val switchBtn = findViewById<ImageButton>(R.id.btnSwitchCamera)
//
//        val backBtn = findViewById<ImageButton>(R.id.backButton)
//        retakeButton = findViewById(R.id.tvRetakePhoto)
//
//        nameField = findViewById(R.id.nameTextField)
//        emailField = findViewById(R.id.emailTextField)
//        phoneNumberField = findViewById(R.id.phoneNumberTextField)
//        organizationField = findViewById(R.id.OrgTextField)
//        submitButton = findViewById(R.id.submit_button)
//
//        // 2. Init
//        setupMediaPipe()
//        setupValidationListeners()
//        cameraExecutor = Executors.newSingleThreadExecutor()
//
//        // 3. Listeners
//        captureBtn.setOnClickListener { takePhoto() }
//
////        switchBtn.setOnClickListener { flipCamera() }
//
//        backBtn.setOnClickListener {
//            onBackPressedDispatcher.onBackPressed()
//        }
//
//        retakeButton.setOnClickListener { retakePhoto() }
//        submitButton.setOnClickListener { submitData() }
//        RegisterListener()
//        // 4. Start
//        if (allPermissionsGranted()) {
//            startCamera()
//        } else {
//            requestPermissionsLauncher.launch(REQUIRED_PERMISSIONS)
//        }
//    }
//
//
//
//    private  fun RegisterListener(){
//
//
//        nameField.editText!!.addTextChangedListener(object : TextWatcher {
//            override fun beforeTextChanged(
//                s: CharSequence?,
//                start: Int,
//                count: Int,
//                after: Int
//            ) {
//            }
//
//            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
//
//            override fun afterTextChanged(s: Editable?) {
//                val input = s.toString()
//                if (input.isEmpty()) {
//                    nameField.error = null
//                    nameField.isErrorEnabled = false
//                } else if (!s.toString().matches(Regex("^[a-zA-Z ]+\$"))) {
//                    nameField.error = "Invalid Name"
//                } else if (input.count() < 3) {
//                    nameField.error = "The name must contain at least 3 characters"
//                } else {
//                    nameField.error = null
//                    nameField.isErrorEnabled = false
//                }
//            }
//        })
//
//        emailField.editText!!.addTextChangedListener(object : TextWatcher {
//            override fun beforeTextChanged(
//                s: CharSequence?,
//                start: Int,
//                count: Int,
//                after: Int
//            ) {
//            }
//
//            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
//
//            override fun afterTextChanged(s: Editable?) {
//                val email = s.toString().trim()
//                if (email.isEmpty()) {
//                    emailField.error = null
//                    emailField.isErrorEnabled = false
//                } else {
//                    val parts = email.split("@")
//                    if (parts.size != 2 || parts[1].isEmpty() || !parts[1].contains(".")) {
//                        emailField.error = "Invalid email format"
//                    } else {
//                        val isValid = EMAIL_ADDRESS.matcher(email)
//                            .matches() // Additional check for special characters
//                        emailField.error = if (!isValid) "Invalid email format" else null
//                    }
//                    emailField.isErrorEnabled = emailField.error != null
//                }
//            }
//        })
//
//        phoneNumberField.editText!!.addTextChangedListener(object : TextWatcher {
//            override fun beforeTextChanged(
//                s: CharSequence?,
//                start: Int,
//                count: Int,
//                after: Int
//            ) {
//            }
//
//            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
//                val input = s.toString()
//
//                if (input.length < 10 || !input.matches(Regex("^[9876]\\d{0,9}\$"))) {
//                    phoneNumberField.error = "Invalid phone number"
//                } else {
//                    phoneNumberField.error = null
//                    phoneNumberField.isErrorEnabled = false
//                }
//            }
//
//            override fun afterTextChanged(s: Editable?) {}
//        })
//
//
//        organizationField.editText!!.addTextChangedListener(object : TextWatcher {
//            override fun beforeTextChanged(
//                s: CharSequence?,
//                start: Int,
//                count: Int,
//                after: Int
//            ) {
//            }
//
//            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
//                val input = s.toString()
//                if (input.length < 3 || input.length > 50) {
//                    organizationField.error = "Organization must be between 3 and 50 characters"
//                } else {
//                    organizationField.error = null
//                    organizationField.isErrorEnabled = false
//                }
//            }
//
//            override fun afterTextChanged(s: Editable?) {}
//        })
//    }
//
//    // --- Camera Switching Logic ---
//    private fun flipCamera() {
//        cameraSelector = if (cameraSelector == CameraSelector.DEFAULT_FRONT_CAMERA) {
//            CameraSelector.DEFAULT_BACK_CAMERA
//        } else {
//            CameraSelector.DEFAULT_FRONT_CAMERA
//        }
//        startCamera()
//    }
//
//    private fun startCamera() {
//        val cameraProviderFuture = ProcessCameraProvider.getInstance(this)
//
//        cameraProviderFuture.addListener({
//            val cameraProvider: ProcessCameraProvider = cameraProviderFuture.get()
//
//            val preview = Preview.Builder().build().also {
//                it.setSurfaceProvider(viewFinder.surfaceProvider)
//            }
//
//            imageCapture = ImageCapture.Builder()
//                .setCaptureMode(ImageCapture.CAPTURE_MODE_MAXIMIZE_QUALITY)
//                .build()
//
//            try {
//                cameraProvider.unbindAll()
//
//                cameraProvider.bindToLifecycle(
//                    this, cameraSelector, preview, imageCapture
//                )
//
//            } catch (exc: Exception) {
//                Log.e(TAG, "Use case binding failed", exc)
//            }
//
//        }, ContextCompat.getMainExecutor(this))
//    }
//
//    private fun setupValidationListeners() {
//        nameField.editText?.doAfterTextChanged {
//            if (!it.isNullOrBlank() && it.length >= 3) nameField.error = null
//        }
//        emailField.editText?.doAfterTextChanged {
//            if (!it.isNullOrBlank() && Patterns.EMAIL_ADDRESS.matcher(it).matches()) emailField.error = null
//        }
//        phoneNumberField.editText?.doAfterTextChanged {
//            if (!it.isNullOrBlank() && it.length >= 10) phoneNumberField.error = null
//        }
//        organizationField.editText?.doAfterTextChanged {
//            if (!it.isNullOrBlank()) organizationField.error = null
//        }
//    }
//
//    private fun submitData() {
//        if (validateName() && validateEmail() && validatePhone() && validateOrg()) {
//
//            val deviceId = Settings.Secure.getString(contentResolver, Settings.Secure.ANDROID_ID)
//            val jsonResposne =  """
//               {
//                "refId" : "${deviceId}",
//                "collection_name" : "response",
//                "name": "${nameField.editText?.text}",
//                "image" : "$faceImageBase64",
//                "uid" : "$deviceId",
//                "email":"${emailField.editText?.text}",
//                "organisation":"${organizationField.editText?.text}",
//                "phoneNumber":"${phoneNumberField.editText?.text}"
//                }
//            """.trimIndent()
////            onFaceSearchResult?.get()?.onFaceRegistered(
////                jsonResposne, faceImageBase64, endPoint = "/face-search/insert"
////            )
////            finish()
//        }
//    }
//
//    // Validation helpers...
//    private fun validateName(): Boolean {
//        val name = nameField.editText?.text.toString().trim()
//        return if (name.isEmpty()) {
//            nameField.error = "Name is required"; false
//        } else if (name.length < 3) {
//            nameField.error = "Name too short"; false
//        } else {
//            nameField.error = null; true
//        }
//    }
//
//    private fun validateEmail(): Boolean {
//        val email = emailField.editText?.text.toString().trim()
//        return if (email.isEmpty()) {
//            emailField.error = "Email is required"; false
//        } else if (!Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
//            emailField.error = "Invalid email"; false
//        } else {
//            emailField.error = null; true
//        }
//    }
//
//    private fun validatePhone(): Boolean {
//        val phone = phoneNumberField.editText?.text.toString().trim()
//        return if (phone.isEmpty()) {
//            phoneNumberField.error = "Phone required"; false
//        } else if (phone.length < 10) {
//            phoneNumberField.error = "Invalid phone"; false
//        } else {
//            phoneNumberField.error = null; true
//        }
//    }
//
//    private fun validateOrg(): Boolean {
//        val org = organizationField.editText?.text.toString().trim()
//        return if (org.isEmpty()) {
//            organizationField.error = "Organization required"; false
//        } else {
//            organizationField.error = null; true
//        }
//    }
//
//    private fun retakePhoto() {
//        registerView.visibility = View.GONE
//        captureView.visibility = View.VISIBLE
//        profileImage.setImageResource(R.drawable.dummy_person)
//    }
//
//    private fun takePhoto() {
//        val imageCapture = imageCapture ?: return
//
//        // 1. SHOW LOADER & DISABLE BUTTON
//        captureLoader.visibility = View.VISIBLE
//        captureBtn.isEnabled = false
//
//        imageCapture.takePicture(
//            ContextCompat.getMainExecutor(this),
//            object : ImageCapture.OnImageCapturedCallback() {
//                override fun onError(exception: ImageCaptureException) {
//                    Log.e(TAG, "Photo capture failed: ${exception.message}", exception)
//                    // Hide loader on error
//                    captureLoader.visibility = View.GONE
//                    captureBtn.isEnabled = true
//                }
//
//                override fun onCaptureSuccess(image: ImageProxy) {
//
//                    captureLoader.visibility = View.VISIBLE
//                    captureBtn.isEnabled = false
//
//                    cameraExecutor.execute {
//
//                        try {
//                            val bitmap = imageProxyToBitmap(image)
//
//                            val mpImage = com.google.mediapipe.framework.image.BitmapImageBuilder(bitmap).build()
//                            val result = faceLandmarker.detect(mpImage)
//
//                            if (result.faceLandmarks().isEmpty()) {
//                                runOnUiThread {
//                                    showFaceAlert("No face detected")
//                                    captureLoader.visibility = View.GONE
//                                    captureBtn.isEnabled = true
//                                }
//                                image.close()
//                                return@execute
//                            }
//
//                            val validFaces = result.faceLandmarks().filter { it.size > 400 }
//
//                            if (validFaces.size != 1) {
//                                runOnUiThread {
//                                    showFaceAlert("Multiple faces detected")
//                                    captureLoader.visibility = View.GONE
//                                    captureBtn.isEnabled = true
//                                }
//                                image.close()
//                                return@execute
//                            }
//
//                            val landmarks = validFaces[0]
//
//                            if (!isFaceFrontal(landmarks)) {
//                                runOnUiThread {
//                                    showFaceAlert("Please look straight")
//                                    captureLoader.visibility = View.GONE
//                                    captureBtn.isEnabled = true
//                                }
//                                image.close()
//                                return@execute
//                            }
//
//                            if (!isFaceInsideFrame(landmarks)) {
//                                runOnUiThread {
//                                    showFaceAlert("Keep your face fully inside frame")
//                                    captureLoader.visibility = View.GONE
//                                    captureBtn.isEnabled = true
//                                }
//                                image.close()
//                                return@execute
//                            }
//
//                            val deviceId = Settings.Secure.getString(contentResolver, Settings.Secure.ANDROID_ID)
//
//                            val resizedBitmap = Bitmap.createScaledBitmap(bitmap, 480, 640, true)
//                            faceImageBase64 = BitmapUtils.BitmaptoBase64(resizedBitmap) ?: ""
//
//                            runOnUiThread {
//                                onFaceSearchResult?.get()?.onFaceRegistered(
//                                    deviceId,
//                                    faceImageBase64,
//                                    "/face-search/insert"
//                                )
//
//                                captureLoader.visibility = View.GONE
//                                captureBtn.isEnabled = true
//                                finish()
//                            }
//
//                        } catch (e: Exception) {
//                            runOnUiThread {
//                                showFaceAlert("Capture failed")
//                                captureLoader.visibility = View.GONE
//                                captureBtn.isEnabled = true
//                            }
//                        } finally {
//                            image.close()
//                        }
//                    }
//                }
//
////                override fun onCaptureSuccess(image: ImageProxy) {
////                    val bitmap = imageProxyToBitmap(image)
////
////                    val mpImage = com.google.mediapipe.framework.image.BitmapImageBuilder(bitmap).build()
////                    val result = faceLandmarker.detect(mpImage)
////
////                    if (result.faceLandmarks().isEmpty()) {
//////                        Toast.makeText(this@RegisterFaceActivity, "No face detected", Toast.LENGTH_SHORT).show()
////                        showFaceAlert("No face detected")
////                        captureLoader.visibility = View.GONE
////                        captureBtn.isEnabled = true
////                        image.close()
////                        return
////                    }
////
////                    val validFaces = result.faceLandmarks().filter { it.size > 400 }
////
////                    if (validFaces.isEmpty()) {
////                        showFaceAlert("No face detected")
////                        captureLoader.visibility = View.GONE
////                        captureBtn.isEnabled = true
////                        image.close()
////                        return
////                    }
////
////                    if (validFaces.size > 1) {
////                        showFaceAlert("Multiple faces detected")
////                        captureLoader.visibility = View.GONE
////                        captureBtn.isEnabled = true
////                        image.close()
////                        return
////                    }
////
////                    val landmarks = validFaces[0]
////
////                    if (!isFaceFrontal(landmarks)) {
//////                        Toast.makeText(this@RegisterFaceActivity, "Please look straight", Toast.LENGTH_SHORT).show()
////                        showFaceAlert("Please look straight")
////                        captureLoader.visibility = View.GONE
////                        captureBtn.isEnabled = true
////                        image.close()
////                        return
////                    }
////
////                    if (!isFaceInsideFrame(landmarks)) {
////                        showFaceAlert("Keep your face fully inside the frame.")
////                        captureLoader.visibility = View.GONE
////                        captureBtn.isEnabled = true
////                        image.close()
////                        return
//////                        Log.e("RegisterFaceActivity", "Keep face inside frame")
//////                        return
////                    }
////
////                    val deviceId = Settings.Secure.getString(contentResolver, Settings.Secure.ANDROID_ID)
////
////                    faceImageBase64 = BitmapUtils.BitmaptoBase64(bitmap) ?: ""
////
////                    onFaceSearchResult?.get()?.onFaceRegistered(
////                        deviceId,
////                        faceImageBase64,
////                        endPoint = "/face-search/insert"
////                    )
////
////                    finish()
////
////                    captureLoader.visibility = View.GONE
////                    captureBtn.isEnabled = true
////                    image.close()
////                }
//
//
////                override fun onCaptureSuccess(image: ImageProxy) {
////                    val bitmap = imageProxyToBitmap(image)
////                    val deviceId = Settings.Secure.getString(contentResolver, Settings.Secure.ANDROID_ID)
////                    faceImageBase64 = BitmapUtils.BitmaptoBase64(bitmap)?:""
////                    onFaceSearchResult?.get()?.onFaceRegistered( deviceId,
////                        faceImageBase64, endPoint = "/face-search/insert"
////                    )
////                    finish()
//////                    val isLive = checkLiveness(bitmap)
////
//////                    if (isLive) {
////////                        captureView.visibility = View.GONE
////////                        registerView.visibility = View.VISIBLE
////////                        profileImage.setImageBitmap(bitmap)
//////
//////
//////                    } else {
//////                        Toast.makeText(baseContext, "Please take a photo of your live face.", Toast.LENGTH_SHORT).show()
//////                    }
////
////                    // 2. HIDE LOADER & ENABLE BUTTON (Always do this at end of success)
////                    captureLoader.visibility = View.GONE
////                    captureBtn.isEnabled = true
////
////                    image.close()
////                }
//            }
//        )
//    }
//
//    private fun showFaceAlert(message: String) {
//        androidx.appcompat.app.AlertDialog.Builder(this)
//            .setTitle("Face Validation")
//            .setMessage(message)
//            .setCancelable(false)
//            .setPositiveButton("OK") { dialog, _ ->
//                dialog.dismiss()
//            }
//            .show()
//    }
//    private fun isFaceInsideFrame(
//        landmarks: List<com.google.mediapipe.tasks.components.containers.NormalizedLandmark>
//    ): Boolean {
//
//        val xs = landmarks.map { it.x() }
//        val ys = landmarks.map { it.y() }
//
//        val left = xs.minOrNull() ?: return false
//        val right = xs.maxOrNull() ?: return false
//        val top = ys.minOrNull() ?: return false
//        val bottom = ys.maxOrNull() ?: return false
//
//        val margin = 0.05f
//
//        return left > margin &&
//                right < (1f - margin) &&
//                top > margin &&
//                bottom < (1f - margin)
//    }
//    private fun isFaceFrontal(landmarks: List<com.google.mediapipe.tasks.components.containers.NormalizedLandmark>): Boolean {
//        val leftEye = landmarks[33]
//        val rightEye = landmarks[263]
//        val noseTip = landmarks[1]
//
//        val eyeLevelDiff = kotlin.math.abs(leftEye.y() - rightEye.y())
//        val midEyeX = (leftEye.x() + rightEye.x()) / 2
//        val noseCenterOffset = kotlin.math.abs(noseTip.x() - midEyeX)
//
//        return eyeLevelDiff < 0.02 && noseCenterOffset < 0.02
//    }
//
//    private val requestPermissionsLauncher = registerForActivityResult(
//        ActivityResultContracts.RequestMultiplePermissions()
//    ) { permissions ->
//        if (permissions.all { it.value }) startCamera() else {
//            Toast.makeText(baseContext, "Permissions denied", Toast.LENGTH_SHORT).show()
//            finish()
//        }
//    }
//
//    private fun setupMediaPipe() {
//        val baseOptions = BaseOptions.builder().setModelAssetPath("face_landmarker.task").build()
//        val options = FaceLandmarker.FaceLandmarkerOptions.builder()
//            .setBaseOptions(baseOptions)
//            .setNumFaces(5)
//            .setOutputFaceBlendshapes(true)
//            .setRunningMode(RunningMode.IMAGE)
//            .build()
//        try {
//            faceLandmarker = FaceLandmarker.createFromOptions(this, options)
//        } catch (e: Exception) { Log.e(TAG, "MediaPipe setup failed", e) }
//    }
//
////    private fun checkLiveness(bitmap: Bitmap): Boolean {
////        try {
////            // Use the two-model spoof pipeline implemented in SpoofChecker.
////            // We call it synchronously here to keep the existing calling flow.
////            return runBlocking { com.pixl.facesearch.FaceAndSpoofDetector.SpoofChecker.isLive(this@RegisterFaceActivity, bitmap) }
////        } catch (e: Exception) {
////            return false
////        }
////    }
//
//    private fun imageProxyToBitmap(image: ImageProxy): Bitmap {
//
//        return if (image.format == android.graphics.ImageFormat.JPEG) {
//
//            val buffer = image.planes[0].buffer
//            val bytes = ByteArray(buffer.remaining())
//            buffer.get(bytes)
//
//            val bitmap = BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
//
//            val rotationDegrees = image.imageInfo.rotationDegrees
//
//            if (rotationDegrees != 0) {
//                val matrix = Matrix()
//                matrix.postRotate(rotationDegrees.toFloat())
//                Bitmap.createBitmap(bitmap, 0, 0, bitmap.width, bitmap.height, matrix, true)
//            } else {
//                bitmap
//            }
//
//        } else {
//
//            val yBuffer = image.planes[0].buffer
//            val uBuffer = image.planes[1].buffer
//            val vBuffer = image.planes[2].buffer
//
//            val ySize = yBuffer.remaining()
//            val uSize = uBuffer.remaining()
//            val vSize = vBuffer.remaining()
//
//            val nv21 = ByteArray(ySize + uSize + vSize)
//
//            yBuffer.get(nv21, 0, ySize)
//            vBuffer.get(nv21, ySize, vSize)
//            uBuffer.get(nv21, ySize + vSize, uSize)
//
//            val yuvImage = android.graphics.YuvImage(
//                nv21,
//                android.graphics.ImageFormat.NV21,
//                image.width,
//                image.height,
//                null
//            )
//
//            val out = java.io.ByteArrayOutputStream()
//            yuvImage.compressToJpeg(
//                android.graphics.Rect(0, 0, image.width, image.height),
//                100,
//                out
//            )
//
//            val bytes = out.toByteArray()
//            val bitmap = BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
//
//            val rotationDegrees = image.imageInfo.rotationDegrees
//
//            if (rotationDegrees != 0) {
//                val matrix = Matrix()
//                matrix.postRotate(rotationDegrees.toFloat())
//                Bitmap.createBitmap(bitmap, 0, 0, bitmap.width, bitmap.height, matrix, true)
//            } else {
//                bitmap
//            }
//        }
//    }
//
//    private fun allPermissionsGranted() = REQUIRED_PERMISSIONS.all {
//        ContextCompat.checkSelfPermission(baseContext, it) == PackageManager.PERMISSION_GRANTED
//    }
//
//    override fun onDestroy() {
//        super.onDestroy()
//        cameraExecutor.shutdown()
//    }
//}