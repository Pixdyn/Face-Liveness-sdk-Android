package com.pixl.facesearch.Https

import android.annotation.SuppressLint
import android.util.Log
import com.pixl.facesearch.CameraAndFace.SDKConfig
import okhttp3.*
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.io.IOException
import java.util.concurrent.TimeUnit

class HttpRequestHelper {


    companion object {

        val client: OkHttpClient = OkHttpClient.Builder()
            .connectTimeout(15, TimeUnit.SECONDS) // time to connect to server
            .readTimeout(30, TimeUnit.SECONDS)     // time to wait for server response
            .writeTimeout(30, TimeUnit.SECONDS)    // time to send the request
            .build()

        fun post(bas64: String, callback: (String) -> Unit) {


            val json: String
            if (SDKConfig.isAttandance && SDKConfig.isFaceRegistration) {
                json = """
        {
            "accountId": "${SDKConfig.accountId}",
            "recordId": "${SDKConfig.recordId}",
            "refId": "string",
            "image": "${bas64.replace(" ", "")}"
        }
    """.trimIndent()
            } else {
                json = """
        {
            "accountId": "${SDKConfig.accountId}",
            "refId": "string",
            "image": "${bas64.replace(" ", "")}"
        }
    """.trimIndent()
            }

//            val json = """
//        {
//            "recordId": "string",
//            "image": "${bas64.replace(" ", "")}"
//        }
//    """.trimIndent()

            val url = "${SDKConfig.baseURL}/searchFace"
            val curl = """
curl --location '$url' \
--header 'accept: application/json' \
--header 'Content-Type: application/json' \
--header 'key: dsfsdfow3i234rndfsdfow3i234rn4dfow3i234rn34dfow3i234rn893m23rnfsdfsdfs4348932' \
--data '$json'
""".trimIndent()

            Log.e("CURL_REQUEST", curl)
            Log.d("FACE_SEARCH_URL", "${SDKConfig.baseURL}/searchFace")
            Log.d("FACE_SEARCH_BODY", JSONObject(json).toString(4))
            Log.d("FACE_SEARCH_ACCOUNT_ID", SDKConfig.accountId)
            Log.d("FACE_SEARCH_RECORD_ID", SDKConfig.recordId)

            val requestBody = RequestBody.create("application/json".toMediaTypeOrNull(), json)
//            https://api-uat.pixl.ai/face-search/search
//            https://api.pixl.ai/mobile/search --> For Visitor Management
//            https://devapi.pixl.ai/face-search-demo/search --> For Test & Client Demo
            val request = Request.Builder()
                .url("${SDKConfig.baseURL}/searchFace") //https://api.pixl.ai/faceSearch/   //.url("${BaseURL.baseURL}/face-search/search")
//                ${BaseURL.baseURL}/faceSearch/searchFace
                .post(requestBody)
                .addHeader("accept", "application/json")
                .addHeader("key", "dsfsdfow3i234rndfsdfow3i234rn4dfow3i234rn34dfow3i234rn893m23rnfsdfsdfs4348932")
                .build()

            val buffer = okio.Buffer()
            requestBody.writeTo(buffer)
            Log.d("REQUEST_BODY", buffer.readUtf8())

            client.newCall(request).enqueue(object : Callback {
                override fun onResponse(call: Call, response: Response) {
                    if (response.isSuccessful) {
                        val responseBody = response.body?.string()
                        Log.e("jsonStructre", responseBody.toString())
                        callback(responseBody ?: "")
                    } else {
//                        callback("Error: ${response.code}")
                        val responseString = response.body?.string()

                        Log.e("HTTP_CODE", response.code.toString())
                        Log.e("HTTP_RESPONSE", responseString ?: "Empty")

                        callback(responseString ?: "Error: ${response.code}")
                    }
                }

                override fun onFailure(call: Call, e: IOException) {
                    Log.e("NetworkError", "Error occurred: ${e.message}", e)
                    callback("Error: ${e.message}")
                }
            })
        }
        fun addNewUser(image: String,
                       uid: String,
                       name: String,
                       organisation: String,
                       phoneNumber: String,
                       email: String,
                       callback: (String, Boolean) -> Unit) {
            val json = JSONObject().apply {
                put("image", image)
                put("uid", uid)
                put("name", name)
                put("organisation", organisation)
                put("phoneNumber", phoneNumber)
                put("email", email)
            }.toString()

            val requestBody = RequestBody.create("application/json".toMediaTypeOrNull(), json)
//            .url("")
//            https://api-uat.pixl.ai/face-search/insert
//            https://api.pixl.ai/mobile/insert --> For Visitor Management
//            https://devapi.pixl.ai/face-search-demo/insert --> For Test & Client Demo
            val request = Request.Builder()
                .url("${SDKConfig.baseURL}/faceSearch/faceInsert") //https://api.pixl.ai/faceSearch
                .post(requestBody)
                .addHeader("accept", "application/json")
                .addHeader("key", "dsfsdfow3i234rndfsdfow3i234rn4dfow3i234rn34dfow3i234rn893m23rnfsdfsdfs4348932")
                .build()

            client.newCall(request).enqueue(object : Callback {
                override fun onResponse(call: Call, response: Response) {
                    val responseBody = response.body?.string()

                    if (response.isSuccessful) {
                        response.body?.let { responseBody ->
                            val jsonResponse = JSONObject(responseBody.string())
                            val status = jsonResponse.getBoolean("status")
                            val message = jsonResponse.getString("message")
                            if (status) {
                                callback("", status)
                            } else {
                                callback(message, status)
                            }

                        }
//                        callback(responseBody ?: "")
                    } else {
                        val errorMessage = "Error: ${response.code}: ${responseBody ?: "Unknown error"}"
                        callback(errorMessage, false)
//                        callback(errorMessage)
                    }
                }

                override fun onFailure(call: Call, e: IOException) {
                    val errorMessage = "Error: ${e.message}"
                    callback(errorMessage, false)
                }
            })
        }

        @SuppressLint("SuspiciousIndentation")
        fun validateData(baseURL: String, name: String, organisation: String, email: String, phoneNumber: String, uid: String, image: String, callback: (String, Boolean) -> Unit) {

            val json: String
            if (SDKConfig.isAttandance && SDKConfig.isFaceRegistration) {
                json = JSONObject().apply {
                    put("accountId", SDKConfig.accountId)
                    put("recordId", SDKConfig.recordId)
                    put("image", image)
                    put("uid", uid)
                    put("name", name)
                    put("organisation", organisation)
                    put("phoneNumber", phoneNumber)
                    put("email", email)
                }.toString()
            } else {
                json = JSONObject().apply {
                    put("accountId", SDKConfig.accountId)
                    put("image", image)
                    put("uid", uid)
                    put("name", name)
                    put("organisation", organisation)
                    put("phoneNumber", phoneNumber)
                    put("email", email)
                }.toString()
            }

            Log.d("VALIDATE_PAYLOAD", json)

            val requestBody = RequestBody.create("application/json".toMediaTypeOrNull(), json)
            val request = Request.Builder()
//            https://visit-live.pixl.ai/faceSearch/faceInsert  --> Live URL
//            https://visitor-management.pixl.ai/faceSearch/faceInsert
//            https://api-uat.pixl.ai/mobile/insert
                        .url("${baseURL}/faceInsert") //https://visit-fedserv.pixl.ai/faceSearch/faceInsert
//                        ${BaseURL.baseURL}/faceSearch/faceInsert
                        .post(requestBody)
                        .addHeader("accept", "application/json")
                        .addHeader("key", "dsfsdfow3i234rndfsdfow3i234rn4dfow3i234rn34dfow3i234rn893m23rnfsdfsdfs4348932")
                        .build()

                    client.newCall(request).enqueue(object : Callback {
//                        override fun onResponse(call: Call, response: Response) {
////                            val responseString = response.body?.string()
////                            Log.d("VALIDATE", "HTTP Code = ${response.code}")
////                            Log.d("VALIDATE", "HTTP Success = ${response.isSuccessful}")
////                            Log.d("VALIDATE", "Response = $responseString")
//
//                            response.body?.let { responseBody ->
//                                if (response.isSuccessful) {
//                                    response.body?.let { responseBody ->
//                                        val jsonResponse = JSONObject(responseBody.string())
//                                        val status = jsonResponse.getBoolean("status")
//                                        val message = jsonResponse.getString("message")
//                                        Log.e("Validation status", status.toString())
//                                        Log.e("Validation message", message)
//                                        if (status) {
//                                            callback(message, status)
//                                        } else {
//                                            callback(message, status)
//                                        }
//                                    }
//                                } else {
//                                    callback("Request Failed, Some Internal Issue. Please Try Again", false)
//                                }
//                            }
//
//                }

                        override fun onResponse(call: Call, response: Response) {

                            val responseString = response.body?.string().orEmpty()

                            Log.d("VALIDATE", "HTTP Code = ${response.code}")
                            Log.d("VALIDATE", "HTTP Success = ${response.isSuccessful}")
                            Log.d("VALIDATE", "Response = $responseString")

                            if (!response.isSuccessful) {
                                callback("Request Failed, Some Internal Issue. Please Try Again", false)
                                return
                            }

                            try {
                                val json = JSONObject(responseString)

                                val status = json.optBoolean("status", false)
                                val message = json.optJSONObject("data")
                                    ?.optString("msg")
                                    ?: json.optString("message", "Unknown response")

                                callback(message, status)

                            } catch (e: Exception) {
                                e.printStackTrace()
                                callback("Invalid server response", false)
                            }
                        }

                override fun onFailure(call: Call, e: IOException) {
                    callback("Request Failed, Some Internal Issue. Please Try Again", false)
                }
            })
        }

        fun faceMatch(
            face1: String,
            face2: String,
            callback: (response: String, isMatch: Boolean, isError: Boolean) -> Unit
        ) {
            val url =
                "https://devapi.pixl.ai/face-match-pcs-development/match_updated_v3"

            try {

                /**
                 * Keeps the required format:
                 *
                 * image/png;base64,<base64-data>
                 *
                 * If the input already contains a data-url prefix,
                 * keep it.
                 *
                 * If the input contains only Base64, add the prefix.
                 */
                fun prepareFaceImage(image: String): String {
                    val cleaned = image
                        .replace(" ", "")
                        .replace("\n", "")
                        .replace("\r", "")
                        .trim()

                    return when {
                        cleaned.startsWith("data:image/png;base64,") -> {
                            cleaned
                        }

                        cleaned.startsWith("image/png;base64,") -> {
                            "data:$cleaned"
                        }

                        cleaned.startsWith("data:image/jpeg;base64,") -> {
                            // If API requires PNG specifically, this should
                            // ideally be converted to PNG before this function.
                            cleaned
                        }

                        cleaned.startsWith("image/jpeg;base64,") -> {
                            "data:$cleaned"
                        }

                        else -> {
                            // Raw Base64 -> add required PNG prefix
                            "data:image/png;base64,$cleaned"
                        }
                    }
                }

                val cleanFace1 = prepareFaceImage(face1)
                val cleanFace2 = prepareFaceImage(face2)

                /**
                 * Request body:
                 *
                 * {
                 *   "face1": "data:image/png;base64,...",
                 *   "face2": "data:image/png;base64,..."
                 * }
                 */
                val jsonObject = JSONObject().apply {
                    put("face1", cleanFace1)
                    put("face2", cleanFace2)
                }

                val json = jsonObject.toString()

                Log.d("FACE_MATCH", "========== REQUEST ==========")
                Log.d("FACE_MATCH", "URL = $url")

                Log.d(
                    "FACE_MATCH",
                    "Face1 prefix = ${cleanFace1.take(30)}"
                )

                Log.d(
                    "FACE_MATCH",
                    "Face1 length = ${cleanFace1.length}"
                )

                Log.d(
                    "FACE_MATCH",
                    "Face2 prefix = ${cleanFace2.take(30)}"
                )

                Log.d(
                    "FACE_MATCH",
                    "Face2 length = ${cleanFace2.length}"
                )

                Log.d(
                    "FACE_MATCH",
                    "JSON = $json"
                )
                val curl = """
            curl -X 'POST' \
            '$url' \
            -H 'accept: application/json' \
            -H 'key: dsfsdfow3i234rndfsdfow3i234rn4dfow3i234rn893m23rnfsdfsdfs4348932' \
            -H 'Content-Type: application/json' \
            -d '$json'
        """.trimIndent()

                Log.d("FACE_MATCH_CURL", curl)

                val requestBody = json
                    .toRequestBody("application/json".toMediaType())

                /**
                 * HTTP request
                 */
                val request = Request.Builder()
                    .url(url)
                    .post(requestBody)
                    .addHeader("accept", "application/json")
                    .addHeader(
                        "key",
                        "dsfsdfow3i234rndfsdfow3i234rn4dfow3i234rn34dfow3i234rn893m23rnfsdfsdfs4348932"
                    )
                    .addHeader(
                        "Content-Type",
                        "application/json"
                    )
                    .build()

                client.newCall(request).enqueue(object : Callback {

                    override fun onResponse(
                        call: Call,
                        response: Response
                    ) {

                        val responseString =
                            response.body?.string().orEmpty()

                        Log.d(
                            "FACE_MATCH",
                            "HTTP Code = ${response.code}"
                        )

                        Log.d(
                            "FACE_MATCH",
                            "Response = $responseString"
                        )

                        if (!response.isSuccessful) {

                            callback(
                                "Request failed: ${response.code}",
                                false,
                                true
                            )

                            return
                        }

                        try {

                            val jsonResponse =
                                JSONObject(responseString)

                            val status =
                                jsonResponse.optString("status")

                            val data =
                                jsonResponse.optJSONObject("data")

                            val verified =
                                data?.optString("verified").orEmpty()

                            val matchPercentage =
                                data?.optString("match_percentage").orEmpty()

                            val message =
                                data?.optString("msg").orEmpty()

                            val noFaceIn =
                                jsonResponse.optString("no_face_in")

                            Log.d(
                                "FACE_MATCH",
                                "Status = $status"
                            )

                            Log.d(
                                "FACE_MATCH",
                                "Verified = $verified"
                            )

                            Log.d(
                                "FACE_MATCH",
                                "Match Percentage = $matchPercentage"
                            )

                            Log.d(
                                "FACE_MATCH",
                                "Message = $message"
                            )

                            Log.d(
                                "FACE_MATCH",
                                "No Face In = $noFaceIn"
                            )

                            if (status == "success") {

                                when (verified) {

                                    "Match" -> {
                                        callback(
                                            "Match Percentage: $matchPercentage",
                                            true,
                                            false
                                        )
                                    }

                                    "Not Match" -> {
                                        callback(
                                            "Match Percentage: $matchPercentage",
                                            false,
                                            false
                                        )
                                    }

                                    else -> {
                                        callback(
                                            message.ifEmpty {
                                                "Face matching failed"
                                            },
                                            false,
                                            true
                                        )
                                    }
                                }

                            } else {

                                callback(
                                    message.ifEmpty {
                                        "Face matching failed"
                                    },
                                    false,
                                    true
                                )
                            }

                        } catch (e: Exception) {

                            Log.e(
                                "FACE_MATCH",
                                "JSON parsing error",
                                e
                            )

                            callback(
                                "Invalid server response",
                                false,
                                true
                            )
                        }
                    }

                    override fun onFailure(
                        call: Call,
                        e: IOException
                    ) {

                        val msg = when (e) {
                            is java.net.UnknownHostException ->
                                "No internet connection"

                            is java.net.SocketTimeoutException ->
                                "Request timed out"

                            else ->
                                "Request failed: ${e.message}"
                        }

                        Log.e(
                            "FACE_MATCH",
                            "Network error: ${e.message}",
                            e
                        )

                        callback(msg, false, true)
                    }
                })

            } catch (e: Exception) {

                Log.e(
                    "FACE_MATCH",
                    "Request creation error",
                    e
                )

                callback(
                    "Request failed: ${e.message}",
                    false,
                    true
                )
            }
        }

//        fun faceMatch(
//            face1: String,
//            face2: String,
//            callback: (String, Boolean) -> Unit
//        ) {
//
//            val url =
//                "https://devapi.pixl.ai/face-match-pcs-development/match_updated_v3"
//
//            try {
//
//                // Remove spaces and data-url prefix if present
//                val cleanFace1 = face1
//                    .replace(" ", "")
//                    .substringAfter("base64,", face1)
//                    .trim()
//
//                val cleanFace2 = face2
//                    .replace(" ", "")
//                    .substringAfter("base64,", face2)
//                    .trim()
//
//                val json = JSONObject().apply {
//                    put("face1", cleanFace1)
//                    put("face2", cleanFace2)
//                }.toString()
//
//                val curl = """
//            curl -X 'POST' \
//            '$url' \
//            -H 'accept: application/json' \
//            -H 'key: dsfsdfow3i234rndfsdfow3i234rn4dfow3i234rn893m23rnfsdfsdfs4348932' \
//            -H 'Content-Type: application/json' \
//            -d '$json'
//        """.trimIndent()
//
//                Log.d("FACE_MATCH_CURL", curl)
//
//                Log.d("FACE_MATCH_URL", url)
//                Log.d("FACE_MATCH_FACE1_LENGTH", cleanFace1.length.toString())
//                Log.d("FACE_MATCH_FACE2_LENGTH", cleanFace2.length.toString())
//
//                val requestBody = RequestBody.create(
//                    "application/json".toMediaTypeOrNull(),
//                    json
//                )
//
//                val request = Request.Builder()
//                    .url(url)
//                    .post(requestBody)
//                    .addHeader("accept", "application/json")
//                    .addHeader(
//                        "key",
//                        "dsfsdfow3i234rndfsdfow3i234rn4dfow3i234rn34dfow3i234rn893m23rnfsdfsdfs4348932"
//                        //dsfsdfow3i234rndfsdfow3i234rn4dfow3i234rn34dfow3i234rn893m23rnfsdfsdfs4348932
//                    )
//                    .addHeader(
//                        "Content-Type",
//                        "application/json"
//                    )
//                    .build()
//
//                client.newCall(request).enqueue(object : Callback {
//
//                    override fun onResponse(
//                        call: Call,
//                        response: Response
//                    ) {
//
//                        val responseString =
//                            response.body?.string().orEmpty()
//
//                        Log.d(
//                            "FACE_MATCH",
//                            "HTTP Code = ${response.code}"
//                        )
//
//                        Log.d(
//                            "FACE_MATCH",
//                            "Response = $responseString"
//                        )
//
//                        if (!response.isSuccessful) {
//
//                            callback(
//                                "Request failed: ${response.code}",
//                                false
//                            )
//
//                            return
//                        }
//
//                        try {
//
//                            val jsonResponse =
//                                JSONObject(responseString)
//
//                            val status =
//                                jsonResponse.optString("status")
//
//                            val data =
//                                jsonResponse.optJSONObject("data")
//
//                            val verified =
//                                data?.optString("verified").orEmpty()
//
//                            val matchPercentage =
//                                data?.optString("match_percentage").orEmpty()
//
//                            val message =
//                                data?.optString("msg").orEmpty()
//
//                            val noFaceIn =
//                                jsonResponse.optString("no_face_in")
//
//                            Log.d(
//                                "FACE_MATCH",
//                                "Verified = $verified"
//                            )
//
//                            Log.d(
//                                "FACE_MATCH",
//                                "Match Percentage = $matchPercentage"
//                            )
//
//                            Log.d(
//                                "FACE_MATCH",
//                                "Message = $message"
//                            )
//
//                            Log.d(
//                                "FACE_MATCH",
//                                "No Face In = $noFaceIn"
//                            )
//
//                            if (status == "success") {
//
//                                when (verified) {
//
//                                    "Match" -> {
//                                        callback(
//                                            "Match Percentage: $matchPercentage",
//                                            true
//                                        )
//                                    }
//
//                                    "Not Match" -> {
//                                        callback(
//                                            "Match Percentage: $matchPercentage",
//                                            false
//                                        )
//                                    }
//
//                                    else -> {
//                                        callback(
//                                            message.ifEmpty {
//                                                "Face matching failed"
//                                            },
//                                            false
//                                        )
//                                    }
//                                }
//
//                            } else {
//
//                                callback(
//                                    message.ifEmpty {
//                                        "Face matching failed"
//                                    },
//                                    false
//                                )
//                            }
//
//                        } catch (e: Exception) {
//
//                            Log.e(
//                                "FACE_MATCH",
//                                "JSON parsing error",
//                                e
//                            )
//
//                            callback(
//                                "Invalid server response",
//                                false
//                            )
//                        }
//                    }
//
//                    override fun onFailure(call: Call, e: IOException) {
//                        val msg = when (e) {
//                            is java.net.UnknownHostException -> "No internet connection"
//                            is java.net.SocketTimeoutException -> "Request timed out"
//                            else -> "Request failed: ${e.message}"
//                        }
//                        Log.e("FACE_MATCH", "Network error: ${e.message}", e)
//                        callback(msg, false)
//                    }
//                })
//
//            } catch (e: Exception) {
//
//                Log.e(
//                    "FACE_MATCH",
//                    "Request creation error",
//                    e
//                )
//
//                callback(
//                    "Request failed: ${e.message}",
//                    false
//                )
//            }
//        }
    }
}




