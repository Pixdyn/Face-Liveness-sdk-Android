package com.pixl.facesearch.CameraAndFace

import android.Manifest
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.os.Bundle
import android.provider.Settings
import android.util.Log
import android.view.View
import android.widget.TextView
import android.widget.Toast
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.view.PreviewView
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import com.pixl.facesearch.AddNewUser.NewResponseListenerSingleton
import com.pixl.facesearch.AddNewUser.NewUserResponse
import com.pixl.facesearch.FaceAndSpoofDetector.FaceSpoofDetector
import com.pixl.facesearch.FaceAndSpoofDetector.ImageVectorUseCase
import com.pixl.facesearch.InterfaceAndObjects.FaceCroppedListener
import com.pixl.facesearch.FaceAndSpoofDetector.MediapipeFaceDetector
import com.pixl.facesearch.FaceMatchResultCallback
import com.pixl.facesearch.FaceSearchResultCallback
import com.pixl.facesearch.Model.DataViewModel
import com.pixl.facesearch.Model.FaceToastViewModel
import com.pixl.facesearch.Utils.HitCount
import com.pixl.facesearch.databinding.ActivityFaceBinding
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.time.delay
import org.json.JSONObject
import java.lang.ref.WeakReference
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

object SDKConfig {
     var  baseURL: String = ""
     var accountId: String = ""
     var recordId: String = ""
     var isAttandance:Boolean = false
     var isFaceRegistration:Boolean = false
    var userData: UserData? = null
    var isFaceMatch: Boolean = true
    var referenceImage: String = ""
}

data class UserData(
    val name: String,
    val organisation: String,
    val email: String,
    val phoneNumber: String,
    val uid: String
)

object NetworkCall {
    var isCalled: Boolean = false
    var isSpoofCalled: Boolean = false
    var isNetworkChecked: Boolean = false
    var isCaptured: Boolean = false
}

class FaceCameraView : AppCompatActivity(), FaceCroppedListener, NewUserResponse {

    private val CAMERA_PERMISSION_CODE = 101
    private lateinit var faceAnalyzer: FaceAnalyzer
    private lateinit var cameraExecutor: ExecutorService
    private lateinit var previewView: PreviewView

    private val faceHintViewModel: FaceToastViewModel by viewModels()
    private lateinit var faceSubHintText: TextView
    lateinit var binding: ActivityFaceBinding


    companion object {
        public var isEmirateFront: Boolean = true
        private var onFaceSearchResult: WeakReference<FaceSearchResultCallback>? = null

        private var onFaceMatchSearchResult: WeakReference<FaceMatchResultCallback>? = null

        fun setFaceSearchResultCallback(callback: FaceSearchResultCallback) {
            onFaceSearchResult = WeakReference(callback)
        }

        fun setFaceMatchSearchResultCallback(callback: FaceMatchResultCallback) {
            onFaceMatchSearchResult = WeakReference(callback)
        }
    }


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityFaceBinding.inflate(layoutInflater)
//        binding.progressView.visibility = View.GONE
        setContentView(binding.root)

        NewResponseListenerSingleton.newUserResponseListener = this

        intent.getStringExtra("USER_JSON")?.let { json ->

            try {
                val obj = JSONObject(json)
                SDKConfig.userData = UserData(
                    name = obj.optString("name"),
                    organisation = obj.optString("organisation"),
                    email = obj.optString("email"),
                    phoneNumber = obj.optString("phoneNumber"),
                    uid = obj.optString("uid")
                )
            } catch (e: Exception) {
                e.printStackTrace()
                Toast.makeText(this, "Invalid USER_JSON", Toast.LENGTH_SHORT).show()
                finish()
                return
            }
        }

        faceSubHintText = binding.faceSubHintText

        faceHintViewModel.hideHint()
        // ✅ Observe ViewModel
        faceHintViewModel.faceHintText.observe(this) { text ->
            binding.faceSubHintText.text = text
        }

// 👇 Observe visibility changes
        faceHintViewModel.isHintVisible.observe(this) { isVisible ->
            binding.faceSubHintText.visibility = if (isVisible) View.VISIBLE else View.GONE
        }

// 👇 Observe color changes
        faceHintViewModel.faceHintTextColor.observe(this) { color ->
            binding.faceSubHintText.setTextColor(color)
        }
        cameraExecutor = Executors.newSingleThreadExecutor()
        NetworkCall.isCalled = false
        val mediapipeFaceDetector = MediapipeFaceDetector(this)
        val faceSpoofDetector = FaceSpoofDetector(this,this, this,useGpu = false)
        val imageVectorUseCase = ImageVectorUseCase(mediapipeFaceDetector,faceSpoofDetector)

        faceAnalyzer = FaceAnalyzer(
            this,
            binding.viewCameraPreview,
            faceSpoofDetector,
            imageVectorUseCase,
            binding.cameralayout,
            faceHintViewModel,
            this,
        )

        binding.cameralayout.onBackClick = {
            onBackPressedDispatcher.onBackPressed()
        }

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA)
            == PackageManager.PERMISSION_GRANTED
        ) {

            try {
                HitCount.isFaceDetected = false
                HitCount.resetValues()
                faceAnalyzer.startCamera(this, cameraExecutor)
            } catch (e: Exception) {
                Log.e("exception", "Error starting camera: ${e.message}")
            }

        } else {
            ActivityCompat.requestPermissions(
                this,

                arrayOf(Manifest.permission.CAMERA),
                CAMERA_PERMISSION_CODE
            )
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int, permissions: Array<out String>, grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == CAMERA_PERMISSION_CODE &&
            grantResults.isNotEmpty() &&
            grantResults[0] == PackageManager.PERMISSION_GRANTED
        ) {
            HitCount.isFaceDetected = false
            faceAnalyzer.startCamera(this, cameraExecutor)
        } else {
            Toast.makeText(this, "Camera permission denied", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onFaceMatchDetected(
        response: String,
        faceImage1: String?,
        faceImage2: String?,
        isFaceMatching: Boolean
    ) {
        Log.d("CALLBACK", "onFaceDetected called")
        Log.d("CALLBACK", "isFaceMatching = $isFaceMatching")
        Log.d("CALLBACK", "response = $response")


        lifecycleScope.launch {
            // Hide progress view and show the "success" scan message
//            binding.progressView.visibility = View.VISIBLE
            binding.semiTransparentOverlay.visibility = View.VISIBLE
            binding.scanMessage.visibility = View.VISIBLE // Assuming this is your success message

            if (!isFaceMatching) {
                binding.scanMessage.text = "Face Match Failed"
            } else {
                binding.scanMessage.text = "Face Match Successfully"
            }

            delay(2000)
            // Pass the final response to the parent app's listener
            FaceCameraView.Companion.onFaceMatchSearchResult?.get()?.onFaceDetected( response,
                faceImage1, faceImage2, isFaceMatching
            )
            HitCount.isFaceDetected = false
            // Now, safely finish the activity.
            finish()
        }
    }

    override fun onErroDetected(response: String, faceImage: String?) {
        Log.e("Error", response)
        finish()
    }


    override fun onFaceRegistered(response: String, image: String) {

        lifecycleScope.launch {
            // Hide progress view and show the "success" scan message
//            binding.progressView.visibility = View.VISIBLE
            binding.semiTransparentOverlay.visibility = View.VISIBLE
            binding.scanMessage.visibility = View.VISIBLE // Assuming this is your success message
            // Vibrate or give other feedback
//            val vibrator = getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
//            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
//                vibrator.vibrate(VibrationEffect.createOneShot(200, VibrationEffect.DEFAULT_AMPLITUDE))
//            } else {
//                @Suppress("DEPRECATION")
//                vibrator.vibrate(200)
//            }
            binding.scanMessage.text = "Face Registered Successfully"
            // Wait for a moment so the user can see the success message
            // Pass the final response to the parent app's listener
            delay(2000)
            FaceCameraView.Companion.onFaceSearchResult?.get()?.onFaceRegistered(
                response, image
            )
            HitCount.isFaceDetected = false
            // Now, safely finish the activity.
            finish()
        }
    }

    override fun onSpoofDetected(response: String, image: String) {

        lifecycleScope.launch {
            // Hide progress view and show the "success" scan message
//            binding.progressView.visibility = View.VISIBLE
            binding.semiTransparentOverlay.visibility = View.VISIBLE
            binding.scanMessage.visibility = View.VISIBLE // Assuming this is your success message

            // Vibrate or give other feedback
//            val vibrator = getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
//            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
//                vibrator.vibrate(VibrationEffect.createOneShot(200, VibrationEffect.DEFAULT_AMPLITUDE))
//            } else {
//                @Suppress("DEPRECATION")
//                vibrator.vibrate(200)
//            }
            // Wait for a moment so the user can see the success message

            binding.scanMessage.text = "Liveness Check Failed"

            delay(2000)

            // Pass the final response to the parent app's listener
            FaceCameraView.Companion.onFaceSearchResult?.get()?.onSpoofDetected(
                image,
            )
            HitCount.isFaceDetected = false
            // Now, safely finish the activity.
            finish()
        }

    }

    override fun onFaceDetected(
        response: String,
        image: String,
        isFaceMatching: Boolean
    ) {
        Log.d("CALLBACK", "onFaceDetected called")
        Log.d("CALLBACK", "isFaceMatching = $isFaceMatching")
        Log.d("CALLBACK", "response = $response")


        lifecycleScope.launch {
            // Hide progress view and show the "success" scan message
//            binding.progressView.visibility = View.VISIBLE
            binding.semiTransparentOverlay.visibility = View.VISIBLE
            binding.scanMessage.visibility = View.VISIBLE // Assuming this is your success message

            // Vibrate or give other feedback
//            val vibrator = getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
//            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
//                vibrator.vibrate(VibrationEffect.createOneShot(200, VibrationEffect.DEFAULT_AMPLITUDE))
//            } else {
//                @Suppress("DEPRECATION")
//                vibrator.vibrate(200)
//            }
            // Wait for a moment so the user can see the success message

            if (!isFaceMatching) {
                binding.scanMessage.text = "No Record Found"
            } else {
                binding.scanMessage.text = "Face Detected Successfully"
            }

            delay(2000)
            // Pass the final response to the parent app's listener
            FaceCameraView.Companion.onFaceSearchResult?.get()?.onFaceDetected( response,
                 image, isFaceMatching
            )
            HitCount.isFaceDetected = false
            // Now, safely finish the activity.
            finish()
        }
    }


//    override fun response(response: String, image: String?, isSpoof: Boolean) {
//        lifecycleScope.launch {
//            // Hide progress view and show the "success" scan message
////            binding.progressView.visibility = View.VISIBLE
//            binding.semiTransparentOverlay.visibility = View.VISIBLE
//            binding.scanMessage.visibility = View.VISIBLE // Assuming this is your success message
//
//            // Vibrate or give other feedback
////            val vibrator = getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
////            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
////                vibrator.vibrate(VibrationEffect.createOneShot(200, VibrationEffect.DEFAULT_AMPLITUDE))
////            } else {
////                @Suppress("DEPRECATION")
////                vibrator.vibrate(200)
////            }
//            // Wait for a moment so the user can see the success message
//
//
//            // Pass the final response to the parent app's listener
//            FaceCameraView.Companion.onFaceSearchResult?.get()?.onFaceDetected(
//                deviceId, image, isSpoof, endPoint = "/face-search/search"
//            )
//            HitCount.isFaceDetected = false
//            // Now, safely finish the activity.
//            finish()
//        }
//    }

    override fun startFaceSearch() {

    }

    override fun newUserData(
        image: String,
        name: String,
        email: String,
        phoneNumber: String,
        organization: String
    ) {

        Log.e("FaceCameraView", "newUserData called with image: $image, name: $name, email: $email, phoneNumber: $phoneNumber, organization: $organization")


        lifecycleScope.launch {
            // Hide progress view and show the "success" scan message
//            binding.progressView.visibility = View.VISIBLE
            binding.semiTransparentOverlay.visibility = View.VISIBLE
            binding.scanMessage.visibility = View.VISIBLE // Assuming this is your success message

            binding.scanMessage.text = "Face Registered Successfully"
            delay(2000)
            // Pass the final response to the parent app's listener
            FaceCameraView.Companion.onFaceSearchResult?.get()?.onNewUserRegistered(image,
                name, email, phoneNumber, organization
            )
            HitCount.isFaceDetected = false
            HitCount.resetValues()
            finish()
        }
    }

//    override fun newUserData(
//        image: String,
//        name: String,
//        email: String,
//        phoneNumber: String,
//        organization: String
//    ) {
//        DataViewModel.resetAllValues()
//        HitCount.resetValues()
//        finish()
//    }

    override fun finishActivity() {
        DataViewModel.resetAllValues()
        finish()
    }
    //NewCallBack FaceCrop Listener End
//    companion object {
//        fun showProgressDialog(faceSearchContainer: FaceCameraView) {
//            CoroutineScope(Dispatchers.Main).launch {
////                faceSearchContainer.binding.progressView.visibility = View.VISIBLE
//            }
////            faceSearchContainer.binding.myButton.visibility = View.GONE
////            faceSearchContainer.binding.scannerBar.visibility = View.VISIBLE
//        }
//
//        fun dismissProgressDialog(faceSearchContainer: FaceCameraView) {
//            CoroutineScope(Dispatchers.Main).launch {
//                faceSearchContainer.binding.progressView.visibility = View.GONE
//            }
////            faceSearchContainer.binding.myButton.visibility = View.GONE
////            faceSearchContainer.binding.scannerBar.visibility = View.VISIBLE
//        }
//    }
}