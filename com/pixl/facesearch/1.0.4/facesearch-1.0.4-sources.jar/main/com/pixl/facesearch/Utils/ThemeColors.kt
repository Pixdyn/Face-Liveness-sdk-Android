package com.pixl.facesearch.Utils

import android.content.Context
import android.util.TypedValue
import androidx.annotation.AttrRes
import androidx.annotation.ColorInt
import com.google.android.material.R as MaterialR

/**
 * Resolves a Material theme color attribute from whatever theme the host app applied to the
 * activity, so the SDK's UI follows the host app's branding instead of a hardcoded palette.
 * Falls back to the SDK's default brand color when the host theme doesn't define the attribute.
 */
internal fun Context.resolveThemeColor(
    @AttrRes attrRes: Int,
    @ColorInt fallback: Int
): Int {
    val typedValue = TypedValue()

    if (!theme.resolveAttribute(attrRes, typedValue, true)) {
        return fallback
    }

    return if (typedValue.resourceId != 0) {
        try {
            androidx.core.content.ContextCompat.getColor(this, typedValue.resourceId)
        } catch (e: Exception) {
            fallback
        }
    } else {
        typedValue.data
    }
}

internal fun Context.themeColorPrimary(@ColorInt fallback: Int = DEFAULT_PRIMARY): Int =
    resolveThemeColor(MaterialR.attr.colorPrimary, fallback)

internal fun Context.themeColorOnPrimary(@ColorInt fallback: Int = DEFAULT_ON_PRIMARY): Int =
    resolveThemeColor(MaterialR.attr.colorOnPrimary, fallback)

internal fun Context.themeColorError(@ColorInt fallback: Int = DEFAULT_ERROR): Int =
    resolveThemeColor(MaterialR.attr.colorError, fallback)

private const val DEFAULT_PRIMARY = 0xFF1A82E2.toInt()
private const val DEFAULT_ON_PRIMARY = 0xFFFFFFFF.toInt()
private const val DEFAULT_ERROR = 0xFFB00020.toInt()
