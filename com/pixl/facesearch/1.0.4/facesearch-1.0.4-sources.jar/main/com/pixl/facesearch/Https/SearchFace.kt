package com.pixl.facesearch.Https

import android.annotation.SuppressLint
import android.app.Activity
import android.app.AlertDialog
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.VibrationEffect
import android.os.Vibrator
import android.util.Log
import android.view.LayoutInflater
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import com.pixl.facesearch.AddNewUser.AddNewUserActivity
import com.pixl.facesearch.CameraAndFace.SDKConfig
import com.pixl.facesearch.CameraAndFace.CameraOverlaysView
import com.pixl.facesearch.CameraAndFace.FaceCameraView
import com.pixl.facesearch.Model.DataViewModel
import com.pixl.facesearch.CameraAndFace.NetworkCall
import com.pixl.facesearch.InterfaceAndObjects.FaceCroppedListener
import com.pixl.facesearch.R
import com.pixl.facesearch.Utils.HitCount
import com.pixl.facesearch.Utils.themeColorPrimary
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import org.json.JSONException
import org.json.JSONObject


class FaceProcess {


    companion object {
        private var alertDialog: AlertDialog? = null


        fun getHttpResponse(faceCameraView: FaceCameraView, faceCroppedListener: FaceCroppedListener, context: Context, base64: String, image: String, bitmap: Bitmap) {
            HttpRequestHelper.post(base64) { response ->
                CoroutineScope(Dispatchers.Main).launch {
                    Log.d(ContentValues.TAG, "Response from server: $response")
                    try {
                        val jsonObject = JSONObject(response)

                        val msg = jsonObject.optString("msg", "No message") //message visitor
                        val status = jsonObject.optBoolean("status", false)

                        val dataObject = jsonObject.optJSONObject("data") ?: JSONObject()
                        val name = dataObject.optString("name", "N/A")
                        val organisation = dataObject.optString("organisation", "N/A")
                        val phoneNumber = dataObject.optString("phoneNumber", "N/A")
                        val email = dataObject.optString("email", "N/A")
                        val result = dataObject.optBoolean("result", false)
//                        faceCameraView.binding.progressView.visibility = View.GONE
                        faceCameraView.binding.cameralayout.setScanning(false)

                        if (result) {
                            Log.e("Response", response.toString())
                            faceCameraView?.binding?.progressView?.visibility = android.view.View.GONE
                            showDetectedAlertDialogue(faceCameraView, faceCroppedListener, dataObject.toString(), image)
                        } else {
                            Log.e("Response", response.toString())
                            if (HitCount.faceNetworkCallHit <= HitCount.maxFaceDetect) {
//                                HitCount.faceNetworkCallHit++
                                HitCount.isProcessing = false
//                                delay(500)
                                NetworkCall.isCalled = false
                                HitCount.isFaceDetected = false //camera will detect face again then show the dialog
                                Log.d("HitCount", "faceNetworkCallHit = ${HitCount.faceNetworkCallHit}")
//                                faceCameraView.binding.cameralayout.setBorderState(CameraOverlaysView.BorderState.FACE_FAILED)
                            } else {
                                faceCameraView?.binding?.progressView?.visibility = android.view.View.GONE
                                if (SDKConfig.isAttandance) {
                                    faceCroppedListener.onFaceDetected(response, image, false)
                                } else {
                                    showDetectedNoRecordsAlertDialogue(faceCameraView, faceCroppedListener, context, image, bitmap, response, result)
                                }
                            }
                        }
                        Log.d(ContentValues.TAG, "Name received from server: $name")
                    } catch (e: JSONException) {
                        faceCameraView.binding.cameralayout.setScanning(false)
                        Log.e(ContentValues.TAG, "Error parsing JSON: ${e.message}")
                        showErrorDialog("Internal Issue",
                            "Internal issue occurred. Please try again later.", context)
                    }
                }
            }
        }

//         fun getHttpResponse(faceCameraView: FaceCameraView, faceCroppedListener: FaceCroppedListener ,context: Context, base64: String, image: String, bitmap: Bitmap) {
//            HttpRequestHelper.post(base64) { response ->
//                CoroutineScope(Dispatchers.Main).launch {
//                    Log.d(ContentValues.TAG, "Response from server: $response")
//                    try {
//                        val jsonObject = JSONObject(response)
//
//                        val msg = jsonObject.optString("msg", "No message") //message visitor
//                        val status = jsonObject.optBoolean("status", false)
//
//                        val dataObject = jsonObject.optJSONObject("data")
//                        val name = dataObject.optString("name", "N/A")
//                        val organisation = dataObject.optString("organisation", "N/A")
//                        val phoneNumber = dataObject.optString("phoneNumber", "N/A")
//                        val email = dataObject.optString("email", "N/A")
//                        val result = dataObject.optBoolean("result", false)
////                        faceCameraView.binding.progressView.visibility = View.GONE
//                        faceCameraView.binding.cameralayout.setScanning(false)
//
//                        if (result) {
//                            Log.e("Response", response.toString())
//                            faceCameraView?.binding?.progressView?.visibility = android.view.View.GONE
//                            showDetectedAlertDialogue(faceCameraView, faceCroppedListener, dataObject.toString(), image)
//                        } else {
//                            Log.e("Response", response.toString())
//                            if (HitCount.faceNetworkCallHit <= HitCount.maxFaceDetect) {
////                                HitCount.faceNetworkCallHit++
//                                HitCount.isProcessing = false
////                                delay(500)
//                                NetworkCall.isCalled = false
//                                HitCount.isFaceDetected = false //camera will detect face again then show the dialog
//                                Log.d("HitCount", "faceNetworkCallHit = ${HitCount.faceNetworkCallHit}")
////                                faceCameraView.binding.cameralayout.setBorderState(CameraOverlaysView.BorderState.FACE_FAILED)
//                            } else {
//                                faceCameraView?.binding?.progressView?.visibility = android.view.View.GONE
//                                if (SDKConfig.isAttandance) {
//                                    faceCroppedListener.onFaceDetected(response, image, false)
//                                } else {
//                                    showDetectedNoRecordsAlertDialogue(faceCameraView,faceCroppedListener, context ,image, bitmap, response, result)}
//
//                            }
//                        }
//                        Log.d(ContentValues.TAG, "Name received from server: $name")
//                    } catch (e: JSONException) {
//                        faceCameraView.binding.cameralayout.setScanning(false)
//                        Log.e(ContentValues.TAG, "Error parsing JSON: ${e.message}")
//                showErrorDialog( "Internal Issue",
//                    "Internal issue occurred. Please try again later.", context)
//                    }
//                }
//            }
//        }


        fun showErrorDialog(title: String, message: String, context: Context) {
            Handler(Looper.getMainLooper()).post {
                val alertDialog = AlertDialog.Builder(context)
                    .setTitle(title)
                    .setCancelable(false)
                    .setMessage(message)
                    .setPositiveButton("Rescan") { dialog, _ ->
                        NetworkCall.isCalled = false
                        HitCount.resetValues()
                        dialog.dismiss()
                    }
                    .show()
                alertDialog.setCanceledOnTouchOutside(false)
                alertDialog.setCancelable(false)
                val positiveButton = alertDialog.getButton(AlertDialog.BUTTON_POSITIVE)
                val negativeButton = alertDialog.getButton(AlertDialog.BUTTON_NEGATIVE)
                positiveButton?.setTextColor(context.themeColorPrimary())
                negativeButton?.setTextColor(context.themeColorPrimary())
            }
        }



        @SuppressLint("SetTextI18n", "ResourceType")
        private fun showDetectedAlertDialogue(
            faceCameraView: FaceCameraView,
            faceCroppedListener: FaceCroppedListener,
            response: String,
            image: String
        ) {
            faceCroppedListener.onFaceDetected(response, image, true)
        }



        @SuppressLint("SetTextI18n")
        private fun showDetectedNoRecordsAlertDialogue(
            faceCameraView: FaceCameraView,
            faceCroppedListener: FaceCroppedListener,
            context: Context,
            image: String,
            bitmap: Bitmap,
            response: String,
            result: Boolean
        ) {

            faceCameraView.runOnUiThread {
                CoroutineScope(Dispatchers.Main).launch {

                    faceCameraView.binding.cameralayout.setBorderState(CameraOverlaysView.BorderState.FACE_FAILED)
                    val dialogView =
                        LayoutInflater.from(context).inflate(R.layout.sucess_custom_dialog, null)
                    val activity = context as? Activity
                    if (activity != null && !activity.isFinishing && !activity.isDestroyed) {
                        val alertDialogBuilder = AlertDialog.Builder(activity)
                        alertDialogBuilder.setView(dialogView)

                        val vibrator =
                            faceCameraView.getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                            vibrator.vibrate(
                                VibrationEffect.createOneShot(
                                    500,
                                    VibrationEffect.DEFAULT_AMPLITUDE
                                )
                            )
                        } else {
                            vibrator.vibrate(500)
                        }

                        val faceImageView = dialogView.findViewById<ImageView>(R.id.faceImageView)
                        val nameTextView = dialogView.findViewById<TextView>(R.id.nameTextView)
                        val msgTextView = dialogView.findViewById<TextView>(R.id.msgTextView)
                        val linearLayout =
                            dialogView.findViewById<LinearLayout>(R.id.dialogLinearLayout)

                        nameTextView.text = "\uD83D\uDE11"
                        msgTextView.text = "Face detected, but no similar records found."
                        DataViewModel.setBaseurl(SDKConfig.baseURL)
                        DataViewModel.setImageBase64(image)
                        alertDialogBuilder.setNegativeButton("Add New Face") { dialog, _ ->
                            faceCameraView.binding.cameralayout.setBorderState(CameraOverlaysView.BorderState.DEFAULT)
                            Log.e("BaseURL", SDKConfig.baseURL.toString())
                            Log.e("Imaage", DataViewModel.imageBase64.value.toString())
                            val intent = Intent(context, AddNewUserActivity::class.java)
                            context.startActivity(intent)
                            HitCount.resetValues()
                            dialog.dismiss()
                        }
                        alertDialogBuilder.setPositiveButton(android.R.string.ok) { dialog, _ ->
                            faceCameraView.binding.cameralayout.setBorderState(CameraOverlaysView.BorderState.DEFAULT)
                            NetworkCall.isCalled = false
                            faceCameraView.finish()
                            HitCount.resetValues()
                            dialog.dismiss()
                        }

                        alertDialog = alertDialogBuilder.create()

                        alertDialog?.setCanceledOnTouchOutside(false) // Disable outside touch
                        alertDialog?.setCancelable(false)

                        alertDialog?.setOnShowListener {
                            alertDialog?.getButton(AlertDialog.BUTTON_POSITIVE)
                                ?.setTextColor(context.themeColorPrimary())
                            alertDialog?.getButton(AlertDialog.BUTTON_NEGATIVE)
                                ?.setTextColor(context.themeColorPrimary())
                        }
                        faceImageView.setImageBitmap(bitmap)
                        alertDialog?.show()
                    }
                }
            }
        }

        fun showSpoofFaceNotDetectedDialog(context: Context) {
            Handler(Looper.getMainLooper()).post {
//                speak("Face Spoof Detected")
                if (context is Activity && !(context as Activity).isFinishing && !(context as Activity).isDestroyed) {
                    alertDialog = AlertDialog.Builder(context)
                        .setTitle("Liveliness Check Failed")
                        .setMessage("Unable to verify liveliness. Please try again.")
                        .setPositiveButton("OK") { dialog, _ ->
                            NetworkCall.isSpoofCalled = false
                            dialog.dismiss()
                        }
                        .setCancelable(false)
                        .create()

                    alertDialog?.show()
                }
            }
        }
    }
}
