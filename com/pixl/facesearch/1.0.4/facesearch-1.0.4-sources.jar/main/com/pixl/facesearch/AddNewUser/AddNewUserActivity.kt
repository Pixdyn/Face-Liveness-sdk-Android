package com.pixl.facesearch.AddNewUser

import android.app.AlertDialog
import android.app.Dialog
import android.content.ContentValues.TAG
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.Editable
import android.text.InputFilter
import android.text.Spanned
import android.text.TextWatcher
import android.util.Base64
import android.util.Log
import android.util.Patterns.EMAIL_ADDRESS
import android.view.Window
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.TextView
import com.pixl.facesearch.CameraAndFace.SDKConfig
import com.pixl.facesearch.Https.HttpRequestHelper
import com.pixl.facesearch.Model.DataViewModel
import com.pixl.facesearch.CameraAndFace.NetworkCall
import com.pixl.facesearch.R
import com.google.android.material.textfield.TextInputLayout
import com.pixl.facesearch.Utils.themeColorPrimary
import java.util.UUID


interface NewUserResponse {
    fun newUserData(imageView: String,name: String, email: String, phoneNumber: String, organization: String)
}

object NewResponseListenerSingleton {
    var newUserResponseListener: NewUserResponse? = null
}

class AddNewUserActivity : AppCompatActivity() {

    private lateinit var nameLayout: TextInputLayout
    private lateinit var phoneNumberLayout: TextInputLayout
    private lateinit var emailIdLayout: TextInputLayout
    private lateinit var orgLayout: TextInputLayout

    private lateinit var capturedImage: String

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        Log.e("Bsdr", "TestHDa")
        setContentView(R.layout.activity_newuser)

//        Log.e("BaseURL2", BaseURL.baseURL.toString())
        Log.e("BaseURL2",DataViewModel.baseURL.value.toString())
        Log.e("Imaage2", DataViewModel.imageBase64.value.toString())

        val nameEditText = findViewById<EditText>(R.id.edit_name)
        val phoneNumberEditText = findViewById<EditText>(R.id.edit_phoneNumber)
        val emailEditText = findViewById<EditText>(R.id.edit_email)
        val orgEditText = findViewById<EditText>(R.id.edit_org)
        val submitButton = findViewById<Button>(R.id.submit_button)
        val imageView: ImageView = findViewById<ImageView>(R.id.profileImage)
        nameLayout = findViewById<TextInputLayout>(R.id.nameTextField)
        phoneNumberLayout = findViewById<TextInputLayout>(R.id.phoneNumberTextField)
        emailIdLayout = findViewById<TextInputLayout>(R.id.emailTextField)
        orgLayout = findViewById<TextInputLayout>(R.id.OrgTextField)

        nameEditText.addTextChangedListener(textWatcher)
        phoneNumberEditText.addTextChangedListener(textWatcher)
        emailEditText.addTextChangedListener(textWatcher)
        orgEditText.addTextChangedListener(textWatcher)

        capturedImage = DataViewModel.imageBase64.value.toString()
        val bitmap = decodeBase64Image(capturedImage)
        imageView.setImageBitmap(bitmap)
        val numericFilter = InputFilter { source, start, end, dest, dstart, dend ->
            for (i in start until end) {
                if (!Character.isDigit(source[i])) {
                    return@InputFilter ""
                }
            }
            null
        }

        val phoneLengthFilter = InputFilter.LengthFilter(10)
        phoneNumberEditText.filters = arrayOf(numericFilter, phoneLengthFilter)

        val nameFilter = InputFilter { source, start, end, dest, dstart, dend ->
            for (i in start until end) {
                if (Character.isDigit(source[i])) {
                    return@InputFilter ""
                }
            }
            null
        }

        val nameLengthFilter = InputFilter.LengthFilter(30)
        nameEditText.filters = arrayOf(nameFilter, nameLengthFilter)


        nameEditText.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(
                s: CharSequence?,
                start: Int,
                count: Int,
                after: Int
            ) {
            }

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}

            override fun afterTextChanged(s: Editable?) {
                val input = s.toString()
                if (input.isEmpty()) {
                    nameLayout.error = null
                    nameLayout.isErrorEnabled = false
                } else if (!s.toString().matches(Regex("^[a-zA-Z ]+\$"))) {
                    nameLayout.error = "Invalid Name"
                } else if (input.count() < 3) {
                    nameLayout.error = "The name must contain at least 3 characters"
                } else {
                    nameLayout.error = null
                    nameLayout.isErrorEnabled = false
                }
            }
        })

        emailEditText.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(
                s: CharSequence?,
                start: Int,
                count: Int,
                after: Int
            ) {
            }

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}

            override fun afterTextChanged(s: Editable?) {
                val email = s.toString().trim()
                if (email.isEmpty()) {
                    emailIdLayout.error = null
                    emailIdLayout.isErrorEnabled = false
                } else {
                    val parts = email.split("@")
                    if (parts.size != 2 || parts[1].isEmpty() || !parts[1].contains(".")) {
                        emailIdLayout.error = "Invalid email format"
                    } else {
                        val isValid = EMAIL_ADDRESS.matcher(email)
                            .matches() // Additional check for special characters
                        emailIdLayout.error = if (!isValid) "Invalid email format" else null
                    }
                    emailIdLayout.isErrorEnabled = emailIdLayout.error != null
                }
            }
        })

        phoneNumberEditText.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(
                s: CharSequence?,
                start: Int,
                count: Int,
                after: Int
            ) {
            }

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                val input = s.toString()

                if (input.length < 10 || !input.matches(Regex("^[9876]\\d{0,9}\$"))) {
                    phoneNumberLayout.error = "Invalid phone number"
                } else {
                    phoneNumberLayout.error = null
                    phoneNumberLayout.isErrorEnabled = false
                }
            }

            override fun afterTextChanged(s: Editable?) {}
        })


        orgEditText.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(
                s: CharSequence?,
                start: Int,
                count: Int,
                after: Int
            ) {
            }

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                val input = s.toString()
                if (input.length < 3 || input.length > 50) {
                    orgLayout.error = "Organization must be between 3 and 50 characters"
                } else {
                    orgLayout.error = null
                    orgLayout.isErrorEnabled = false
                }
            }

            override fun afterTextChanged(s: Editable?) {}
        })

        updateButtonColor()

        val patternFilter = object : InputFilter {
            override fun filter(
                source: CharSequence?,
                start: Int,
                end: Int,
                dest: Spanned?,
                dstart: Int,
                dend: Int
            ): CharSequence? {
                return if ("^[a-zA-Z0-9  ]*$".toRegex().matches(source.toString())) {
                    null
                } else {
                    ""
                }
            }
        }

        val lengthFilter = InputFilter.LengthFilter(50)
        orgEditText.filters = arrayOf(lengthFilter, patternFilter)

        val gmailPatternFilter = object : InputFilter {
            override fun filter(
                source: CharSequence?,
                start: Int,
                end: Int,
                dest: Spanned?,
                dstart: Int,
                dend: Int
            ): CharSequence? {
                val regexPattern = "^[a-zA-Z0-9.@\\s]*$".toRegex()
                return if (source != null && !regexPattern.matches(source)) {
                    null
                } else {
                    null
                }
            }
        }

        submitButton.setOnClickListener {

            val name = nameEditText.text.toString()
            val phoneNumber = phoneNumberEditText.text.toString()
            val email = findViewById<EditText>(R.id.edit_email).text.toString()
            val organization = findViewById<EditText>(R.id.edit_org).text.toString()


            if (name.isNotBlank() &&
                phoneNumber.isNotBlank() &&
                email.isNotBlank() &&
                organization.isNotBlank() &&
                isValidName(name) &&
                isValidPhoneNumber(phoneNumber) &&
                isValidEmail(email) &&
                isValidOrganization(organization)
            )

            {
                Log.e("BaseURL", SDKConfig.baseURL)
                Log.e("BaseURL3", SDKConfig.baseURL.toString())
                Log.e("Imaage3", DataViewModel.imageBase64.value.toString())

                val uid = UUID.randomUUID().toString()
                checkDataInDB(name, organization, phoneNumber, email, uid = uid) //"user-data"
            }
        }


        val gmailLengthFilter = InputFilter.LengthFilter(50)
        emailEditText.filters = arrayOf(gmailLengthFilter, gmailPatternFilter)
    }

    private fun decodeBase64Image(base64Image: String): Bitmap? {
        val decodedString = Base64.decode(base64Image, Base64.DEFAULT)
        return BitmapFactory.decodeByteArray(decodedString, 0, decodedString.size)
    }

   private fun checkDataInDB(
        name: String,
        organization: String,
        phoneNumber: String,
        email: String,
        uid: String
    ) {
        Handler(Looper.getMainLooper()).post {
            var progress = showProgressBar()
            Log.e(TAG, "img: ${DataViewModel.imageBase64.value.toString()}")
            HttpRequestHelper.validateData(
                baseURL = DataViewModel.baseURL.value.toString(),
                name = name,
                organisation = organization,
                phoneNumber = phoneNumber,
                email = email,
                uid = uid,
                image = DataViewModel.imageBase64.value.toString(),
                callback = { response, status ->
                    Handler(Looper.getMainLooper()).post {
                        if (status) {
                            try {
                                progress.dismiss()
//                                showFacedAdded(capturedImage,name, email, phoneNumber, organization)
//                                Log.d("AddNewUserFlow", "HTTP callback status=$status response=$response")
                                NewResponseListenerSingleton.newUserResponseListener?.newUserData(
                                    capturedImage,
                                    name,
                                    email,
                                    phoneNumber,
                                    organization
                                )
                                NetworkCall.isCalled = true
                                finish()
                            } catch (e: Exception) {
                                progress.dismiss()
                                showDataErrorDialog(
                                    "Internal Issue",
                                    "Internal issue occurred. Please try again later."
                                )
                            }
                        } else {
                            progress.dismiss()
                            if (response == "Request Failed, Some Internal Issue. Please Try Again") {
                                showDataErrorDialog("Internal Issue", message = response)
                            } else {
                                showDataErrorDialog("Existing Data", message = response)
                            }
                        }
                    }
                })
        }
    }

    private fun updateButtonColor() {
        val nameEditText = findViewById<EditText>(R.id.edit_name)
        val phoneNumberEditText = findViewById<EditText>(R.id.edit_phoneNumber)
        val emailEditText = findViewById<EditText>(R.id.edit_email)
        val orgEditText = findViewById<EditText>(R.id.edit_org)
        val submitButton = findViewById<Button>(R.id.submit_button)

        val isNameValid = isValidName(nameEditText.text.toString().trim())
        val isPhoneNumberValid = isValidPhoneNumber(phoneNumberEditText.text.toString().trim())
        val isEmailValid = isValidEmail(emailEditText.text.toString().trim())
        val isOrgValid = isValidOrganization(orgEditText.text.toString().trim())

        if (isNameValid && isPhoneNumberValid && isEmailValid && isOrgValid) {
            submitButton.setBackgroundColor(themeColorPrimary())
            submitButton.isEnabled = true
        } else {
            submitButton.setBackgroundColor(Color.GRAY)
            submitButton.isEnabled = false
        }
    }

    private fun isValidName(name: String): Boolean {
        return name.matches(Regex("^[a-zA-Z ]+\$"))
    }

    private fun isValidPhoneNumber(phoneNumber: String): Boolean {
        return phoneNumber.matches(Regex("^[9876]\\d{9}\$"))
    }

    private fun isValidOrganization(org: String): Boolean {
        return org.isNotEmpty() && org.length in 3..50
    }

    private fun isValidEmailCustom(email: String): Boolean {
        return true
    }

    private val textWatcher = object : TextWatcher {
        override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}

        override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
            updateButtonColor()
        }

        override fun afterTextChanged(s: Editable?) {

        }
    }

  private fun showFacedAdded(
      imageView: String,
        name: String,
        email: String,
        phoneNumber: String,
        organization: String,
    ) {
        Handler(Looper.getMainLooper()).post {
            val alertDialog = AlertDialog.Builder(this)
                .setTitle("Face Added")
                .setMessage("Hello $name, Your Face Added Successfully.")
                .setPositiveButton(android.R.string.ok) { dialog, _ ->
                    dialog.dismiss()
                    NewResponseListenerSingleton.newUserResponseListener?.newUserData(
                        imageView,
                        name,
                        email,
                        phoneNumber,
                        organization
                    )
                    NetworkCall.isCalled = false
                    finish()
                }
                .show()
            val positiveButton = alertDialog.getButton(AlertDialog.BUTTON_POSITIVE)
            positiveButton?.setTextColor(themeColorPrimary())
        }
    }

    private fun showDataErrorDialog(title: String, message: String) {
        Handler(Looper.getMainLooper()).post {
            val alertDialog = AlertDialog.Builder(this)
                .setTitle(title)
                .setMessage(message)
                .setPositiveButton(android.R.string.ok) { dialog, _ ->
                    dialog.dismiss()
                }
                .show()
            val positiveButton = alertDialog.getButton(AlertDialog.BUTTON_POSITIVE)
            positiveButton?.setTextColor(themeColorPrimary())
        }
    }


    fun isValidEmail(email: String): Boolean {
        val emailParts = email.split("@")
        if (emailParts.size != 2) {
            return false
        }
        val localPart = emailParts[0]
        val domainPart = emailParts[1]

        if (localPart.contains("..")) {
            return false
        }

        val domainParts = domainPart.split(".")
        if (domainParts.any { it.isEmpty() }) {
            return false
        }

        return true
    }


    private fun showProgressBar(): Dialog {
        val dialog = Dialog(this)
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        dialog.setCancelable(false)
        dialog.setContentView(R.layout.progressview)

        dialog.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))

        val pleaseWaitText = dialog.findViewById<TextView>(R.id.pleaseWaitText)
        pleaseWaitText.text = "Please Wait"

        dialog.show()
        return dialog
    }

    companion object {
        private fun isValidEmail(addNewUserActivity: AddNewUserActivity, email: String): Boolean {
            return EMAIL_ADDRESS.matcher(email)
                .matches() && !email.contains(" ") && addNewUserActivity.isValidEmailCustom(email)
        }
    }
}