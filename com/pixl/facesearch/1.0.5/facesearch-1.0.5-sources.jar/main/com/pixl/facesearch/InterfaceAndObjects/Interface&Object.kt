package com.pixl.facesearch.InterfaceAndObjects

import android.graphics.Bitmap

interface SuccessResponse {
    fun resultResponse(response: String)
}

object SuccessResponseListenerSingleton {
    var listener: SuccessResponse? = null
}

//interface ResponseListener {
//    fun onResponseReceived(response: String, image: String)
//    fun cancel()
//    fun newUserResponse(image: String, name: String, email: String, phoneNumber: String, organization: String)
//}

//object ResponseListenerSingleton {
//    var listener: ResponseListener? = null
//}

interface FaceCroppedListener {

    //FaceMatch
    fun onFaceMatchDetected(response: String ,faceImage1: String?, faceImage2: String?, isFaceMatching: Boolean)
    fun onErroDetected(response: String, faceImage: String?)

    //

    fun onFaceRegistered(response: String, image: String)
    fun onSpoofDetected(response: String, image: String)

    fun onFaceLivenessDetected(response: String, image: String)
    fun onFaceDetected(response: String, image: String, isFaceMatching: Boolean)
//    fun response(response: String, image: String?, isSpoof: Boolean)
    fun startFaceSearch()
    fun newUserData(image: String, name: String, email: String, phoneNumber: String, organization: String)
    fun finishActivity()
}