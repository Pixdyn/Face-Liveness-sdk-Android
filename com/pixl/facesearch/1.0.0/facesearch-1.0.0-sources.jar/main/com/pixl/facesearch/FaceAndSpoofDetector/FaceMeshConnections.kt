package com.pixl.facesearch.FaceAndSpoofDetector

val FACE_MESH_CONNECTIONS = listOf(
    // Full 478 connection list from MediaPipe's face mesh topology
    // Only a snippet shown here. You must include the full list.
    // Full list: https://github.com/google/mediapipe/blob/master/mediapipe/modules/face_geometry/data/canonical_face_model.fbx

    // Eyes
    33 to 7, 7 to 163, 163 to 144, 144 to 145, 145 to 153,
    263 to 249, 249 to 390, 390 to 373, 373 to 374, 374 to 380,

    // Face outline
    10 to 338, 338 to 297, 297 to 332, 332 to 284, 284 to 251,
    251 to 389, 389 to 356, 356 to 454, 454 to 323, 323 to 361,
    361 to 288, 288 to 397, 397 to 365, 365 to 379, 379 to 378,
    378 to 400, 400 to 377, 377 to 152, 152 to 148, 148 to 176,
    176 to 149, 149 to 150, 150 to 136, 136 to 172, 172 to 58,
    58 to 132, 132 to 93, 93 to 234, 234 to 127, 127 to 162,
    162 to 21, 21 to 54, 54 to 103, 103 to 67,

    // Lips
    61 to 146, 146 to 91, 91 to 181, 181 to 84, 84 to 17,
    17 to 314, 314 to 405, 405 to 321, 321 to 375, 375 to 291,
    61 to 185, 185 to 40, 40 to 39, 39 to 37, 37 to 0,
    0 to 267, 267 to 269, 269 to 270, 270 to 409, 409 to 291,

    // Nose
    1 to 19, 19 to 94, 94 to 2, 2 to 164, 164 to 0,

    // Iris (left and right)
    474 to 475, 475 to 476, 476 to 477, 477 to 474, 472 to 473,
    473 to 474, 474 to 475, 475 to 472, 469 to 470, 470 to 471,
    471 to 472, 472 to 469,

)
