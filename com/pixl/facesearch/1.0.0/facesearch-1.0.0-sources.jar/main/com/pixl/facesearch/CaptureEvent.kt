package com.pixl.facesearch

import android.graphics.Rect

sealed class CaptureEvent {
    object Idle : CaptureEvent()
    data class Capture(val faceRect: Rect) : CaptureEvent()
}
