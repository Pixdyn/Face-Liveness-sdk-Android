package com.pixl.facesearch.Model

import android.graphics.Color
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.annotation.ColorInt

class FaceToastViewModel : ViewModel() {

    private val _faceHintText = MutableLiveData<String>()
    val faceHintText: LiveData<String> get() = _faceHintText

    private val _isHintVisible = MutableLiveData<Boolean>()
    val isHintVisible: LiveData<Boolean> get() = _isHintVisible

    private val _faceHintTextColor = MutableLiveData<Int>()
    val faceHintTextColor: LiveData<Int> get() = _faceHintTextColor

    // Update text message
    fun setFaceHintText(message: String) {
        _faceHintText.value = message
    }

    // Update text color
    fun setFaceHintColor(@ColorInt color: Int) {
        _faceHintTextColor.value = Color.WHITE
    }

    // Control visibility
    fun showHint() {
        _isHintVisible.value = true
    }

    fun hideHint() {
        _isHintVisible.value = false
    }
}
