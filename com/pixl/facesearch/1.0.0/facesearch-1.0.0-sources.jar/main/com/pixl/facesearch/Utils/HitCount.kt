package com.pixl.facesearch.Utils

class HitCount {

    companion object {
        var networkCallHit: Boolean = false
        var isProcessing: Boolean = false

        var isFaceDetected: Boolean = false
        var faceNetworkCallHit: Int = 0
        var maxFaceDetect: Int = 3


         fun resetValues() {
             isFaceDetected = false
             networkCallHit = false
            isProcessing = false
            faceNetworkCallHit = 0
        }
    }
}