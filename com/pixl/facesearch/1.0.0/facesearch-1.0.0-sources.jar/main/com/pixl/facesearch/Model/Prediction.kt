package com.pixl.facesearch.Model


import android.graphics.RectF

data class Prediction(
    val bbox: RectF,
    val label: String
)
