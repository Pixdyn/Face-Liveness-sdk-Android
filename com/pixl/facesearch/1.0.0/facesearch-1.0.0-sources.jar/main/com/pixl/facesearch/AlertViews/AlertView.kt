package com.pixl.facesearch.AlertViews

import android.annotation.SuppressLint
import android.view.View
import com.pixl.facesearch.CameraAndFace.FaceCameraView
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch


@SuppressLint("SetTextI18n", "ResourceType")
private fun showDetectedAlertDialogue(faceCameraView: FaceCameraView, response: String, image: String) {
//    SuccessResponseListenerSingleton.listener = this
    CoroutineScope(Dispatchers.Main).launch {
        if (faceCameraView != null) {
//            faceCameraView.binding.progressView.visibility = View.GONE

            // Speak the success message
//            speak("Face detected successfully.")
            faceCameraView.binding.semiTransparentOverlay.visibility = View.VISIBLE
            // Show the tick mark
            faceCameraView.binding.scanMessage.visibility = View.VISIBLE
            delay(500) // Adjust duration as needed

            // Hide the overlay and tick mark after the delay
            faceCameraView.binding.semiTransparentOverlay.visibility = View.GONE
            faceCameraView.binding.scanMessage.visibility = View.GONE

            // Call the response method
//            faceCroppedListener.response(response, image)
        }
    }
}
//
//
//@SuppressLint("SetTextI18n")
////
//private fun showDetectedNoRecordsAlertDialogue(faceCameraView: FaceCameraView, faceCroppedListener: FaceCroppedListener, context: Context, image: String, bitmap: Bitmap, response: String, result: Boolean) {
//    SuccessResponseListenerSingleton.listener = this
//    NewResponseListenerSingleton.newUserResponseListener = this
//    var alertDialog: AlertDialog? = null
//
//    faceCameraView.runOnUiThread {
//        CoroutineScope(Dispatchers.Main).launch {
////            FaceSearchContainer.dismissProgressDialog(mainActivity)
//            val dialogView =
//                LayoutInflater.from(context).inflate(R.layout.sucess_custom_dialog, null)
//            val alertDialogBuilder = AlertDialog.Builder(context)
//            alertDialogBuilder.setView(dialogView)
//
//            val vibrator = faceCameraView.getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
//            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
//                vibrator.vibrate(VibrationEffect.createOneShot(500, VibrationEffect.DEFAULT_AMPLITUDE))
//            } else {
//                vibrator.vibrate(500)
//            }
//
//            val faceImageView = dialogView.findViewById<ImageView>(R.id.faceImageView)
//            val nameTextView = dialogView.findViewById<TextView>(R.id.nameTextView)
//            val msgTextView = dialogView.findViewById<TextView>(R.id.msgTextView)
//            val linearLayout = dialogView.findViewById<LinearLayout>(R.id.dialogLinearLayout)
//
//            nameTextView.text = "\uD83D\uDE11"
//            msgTextView.text = "Face detected, but no similar records found."
//            DataViewModel.setImageBase64(image)
//            alertDialogBuilder.setNegativeButton("Add New Face") { dialog, _ ->
//                val intent = Intent(context, AddNewUserActivity::class.java)
//                context.startActivity(intent)
////                faceCroppedListener.startFaceSearch()
//                dialog.dismiss()
//            }
//            alertDialogBuilder.setPositiveButton(android.R.string.ok) { dialog, _ ->
//                dialog.dismiss()
//                faceCroppedListener.finishActivity()
//            }
//
//            alertDialog = alertDialogBuilder.create()
//
//            alertDialog?.setOnShowListener {
//                alertDialog?.getButton(AlertDialog.BUTTON_POSITIVE)
//                    ?.setTextColor(Color.parseColor("#1A82E2"))
//                alertDialog?.getButton(AlertDialog.BUTTON_NEGATIVE)
//                    ?.setTextColor(Color.parseColor("#1A82E2"))
//            }
//            faceImageView.setImageBitmap(bitmap)
//            alertDialog?.show()
//        }
//    }
//}
