package com.pixl.facesearch.FaceAndSpoofDetector

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.Rect
import android.provider.Settings
import android.util.Log
import android.view.View
import androidx.core.graphics.get
import androidx.core.graphics.set
import com.google.mediapipe.tasks.components.containers.NormalizedLandmark
import com.pixl.facesearch.CameraAndFace.CameraOverlaysView
import com.pixl.facesearch.CameraAndFace.FaceCameraView
import com.pixl.facesearch.CameraAndFace.NetworkCall
import com.pixl.facesearch.CameraAndFace.SDKConfig
import com.pixl.facesearch.Https.FaceProcess
import com.pixl.facesearch.Https.HttpRequestHelper
//import com.pixl.facesearch.Constants.LABELS_PATH
//import com.pixl.facesearch.Constants.MODEL_PATH
import com.pixl.facesearch.InterfaceAndObjects.FaceCroppedListener
import com.pixl.facesearch.Utils.BitmapUtils
import com.pixl.facesearch.Utils.HitCount
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import org.opencv.android.OpenCVLoader
//import org.koin.core.annotation.Single
import org.tensorflow.lite.DataType
import org.tensorflow.lite.Interpreter
import org.tensorflow.lite.gpu.CompatibilityList
import org.tensorflow.lite.gpu.GpuDelegate
import org.tensorflow.lite.support.common.FileUtil
import org.tensorflow.lite.support.common.ops.CastOp
import org.tensorflow.lite.support.image.ImageProcessor
import org.tensorflow.lite.support.image.TensorImage
import kotlin.math.exp
import kotlin.time.DurationUnit
import kotlin.time.measureTime

//@Single
enum class FaceQualityIssue {
    NONE,
    LOW_LIGHT,
    OVER_EXPOSED,
    UNEVEN_LIGHT
}

data class LightingStatus(
    val lowLight: Boolean,
    val overExposed: Boolean,
    val unevenLight: Boolean,
    val meanBrightness: Double
)

class FaceSpoofDetector(
    faceCameraView: FaceCameraView,
    faceCroppedListener: FaceCroppedListener,
    context: Context,
    useGpu: Boolean = false,
    useXNNPack: Boolean = false,
    useNNAPI: Boolean = false
) { // : Detector.DetectorListener

    data class FaceSpoofResult(val isSpoof: Boolean, val score: Float, val timeMillis: Long)

    private var faceCameraView: FaceCameraView? = null
    private var faceCroppedListener: FaceCroppedListener? = null
    private val scale1 = 2.7f
    private val scale2 = 4.0f
    private val inputImageDim = 80
    private val outputDim = 3
    private val tfliteLock = Mutex()
    private var firstModelInterpreter: Interpreter
    private var secondModelInterpreter: Interpreter
    private val imageTensorProcessor = ImageProcessor.Builder()
        .add(CastOp(DataType.FLOAT32))
        .build()

    private var frameCounter = 0
//
//    private val detector: Detector by lazy {
//        Detector(context , MODEL_PATH, LABELS_PATH, this).apply {
//            setup()
//        }
//    }

    init {
        // Initialize TFLiteInterpreter
        if (!OpenCVLoader.initDebug()) {
            Log.e("OpenCV", "OpenCV init failed")
        }

        this.faceCameraView = faceCameraView
        this.faceCroppedListener = faceCroppedListener
        val interpreterOptions =
            Interpreter.Options().apply {
                // Add the GPU Delegate if supported.
                // See -> https://www.tensorflow.org/lite/performance/gpu#android
                if (useGpu) {
                    if (CompatibilityList().isDelegateSupportedOnThisDevice) {
                        addDelegate(GpuDelegate(CompatibilityList().bestOptionsForThisDevice))
                    }
                } else {
                    // Number of threads for computation
                    numThreads = 4
                }
                useXNNPACK = useXNNPack
                this.useNNAPI = useNNAPI
            }
        firstModelInterpreter =
            Interpreter(
                FileUtil.loadMappedFile(context, "spoof_model_scale_2_7.tflite"),
                interpreterOptions
            )
        secondModelInterpreter =
            Interpreter(
                FileUtil.loadMappedFile(context, "spoof_model_scale_4_0.tflite"),
                interpreterOptions
            )
    }

    suspend fun detectSpoof(
        context: Context,
        frameImage: Bitmap,
        faceRect: Rect,
        landmarks: List<NormalizedLandmark>,
        cameraOverlayView: CameraOverlaysView
    ): FaceSpoofResult =
        withContext(Dispatchers.Default) {
            frameCounter++
            // Skip the first 4 frames
//            if (frameCounter >= 20) {
//                Log.d("Spoof", "Skipping frame $frameCounter")
//                return@withContext FaceSpoofResult(isSpoof = false, score = 0f, timeMillis = 0L)
//            }

            tfliteLock.withLock {

                if (!isFaceFrontal(landmarks)) {
                    Log.d("Spoof", "Rejected: face not frontal")
                    return@withContext FaceSpoofResult(
                        isSpoof = false,
                        score = 0f,
                        timeMillis = 0L
                    )
                }

                val croppedImage1 = safeCrop(
                    origImage = frameImage,
                    bbox = faceRect,
                    bboxScale = scale1,
                    targetWidth = inputImageDim,
                    targetHeight = inputImageDim
                )
                // Convert RGB -> BGR
                for (i in 0 until croppedImage1.width) {
                    for (j in 0 until croppedImage1.height) {
                        croppedImage1[i, j] = Color.rgb(
                            Color.blue(croppedImage1[i, j]),
                            Color.green(croppedImage1[i, j]),
                            Color.red(croppedImage1[i, j])
                        )
                    }
                }

                val croppedImage2 = safeCrop(
                    origImage = frameImage,
                    bbox = faceRect,
                    bboxScale = scale2,
                    targetWidth = inputImageDim,
                    targetHeight = inputImageDim
                )
                for (i in 0 until croppedImage2.width) {
                    for (j in 0 until croppedImage2.height) {
                        croppedImage2[i, j] = Color.rgb(
                            Color.blue(croppedImage2[i, j]),
                            Color.green(croppedImage2[i, j]),
                            Color.red(croppedImage2[i, j])
                        )
                    }
                }

                val input1 =
                    imageTensorProcessor.process(TensorImage.fromBitmap(croppedImage1)).buffer
                val input2 =
                    imageTensorProcessor.process(TensorImage.fromBitmap(croppedImage2)).buffer
                val output1 = arrayOf(FloatArray(outputDim))
                val output2 = arrayOf(FloatArray(outputDim))

                val time = measureTime {
                    firstModelInterpreter.run(input1, output1)
                    secondModelInterpreter.run(input2, output2)
                }.toLong(DurationUnit.MILLISECONDS)

                val output =
                    softMax(output1[0]).zip(softMax(output2[0])).map { it.first + it.second }
                val label = output.indexOf(output.max())
                val iSpoof = label != 1
                val score = output[label] / 2f

                Log.e(
                    "FACE_FLOW",
                    """
    ===== FACE FLOW =====
    NetworkCall.isCalled = ${NetworkCall.isCalled}
    NetworkCall.isSpoofCalled = ${NetworkCall.isSpoofCalled}
    HitCount.isFaceDetected = ${HitCount.isFaceDetected}
    HitCount.faceNetworkCallHit = ${HitCount.faceNetworkCallHit}
    HitCount.maxFaceDetect = ${HitCount.maxFaceDetect}
    iSpoof = $iSpoof
    SDKConfig.isFaceMatch = ${SDKConfig.isFaceMatch}
    =====================
    """.trimIndent()
                )

                if (!NetworkCall.isCalled && !NetworkCall.isSpoofCalled && !HitCount.isFaceDetected) {
                    if (!iSpoof) {
                        Log.e(
                            "FACE_FLOW",
                            "REAL FACE DETECTED - entering face processing"
                        )
                        HitCount.isFaceDetected = true
                        val scaledBitmap = Bitmap.createScaledBitmap(frameImage, 200, 200, true)
                        val base64Value = BitmapUtils.BitmaptoBase64(scaledBitmap)
                        val headCrop = cropHeadAligned(frameImage, landmarks)


                        val passportBitmap = resizePreserveAspect(
                            headCrop ?: frameImage,
                            targetWidth = 600,
                            targetHeight = 800
                        )
                        val originalImage = BitmapUtils.BitmaptoBase64(passportBitmap)

                        HitCount.faceNetworkCallHit++

                        faceCameraView!!.binding.cameralayout.setProgress(50f)

                        CoroutineScope(Dispatchers.Main).launch {
                            faceCameraView?.binding?.progressView?.visibility = android.view.View.VISIBLE
                        }

                        Log.e(
                            "FACE_FLOW",
                            """
    Before network condition:
    originalImage null = ${originalImage == null}
    faceCameraView null = ${faceCameraView == null}
    faceNetworkCallHit = ${HitCount.faceNetworkCallHit}
    maxFaceDetect = ${HitCount.maxFaceDetect}
    condition = ${
                                originalImage != null &&
                                        faceCameraView != null &&
                                        HitCount.faceNetworkCallHit >= HitCount.maxFaceDetect
                            }
    """.trimIndent()
                        )

                        if (originalImage != null && faceCameraView != null && HitCount.faceNetworkCallHit >= HitCount.maxFaceDetect) {
                            //
                            Log.e("FaceDetection Called", HitCount.faceNetworkCallHit.toString())
                            CoroutineScope(Dispatchers.Main).launch {
                                //  cameraOverlayView.setScanning(true)
                                cameraOverlayView.setProgress(100f)
                            }
                            NetworkCall.isCalled = true

//                            val bitmapForDetection =  com.pixl.facesearch.BitmapUtils.Base64ToBitmap(originalImage)
//                            detector.detect(bitmapForDetection, faceRect, originalImage, context)
//                            detector.detect(originalImage, )
//                            val deviceId = Settings.Secure.getString(
//                                context.contentResolver,
//                                Settings.Secure.ANDROID_ID
//                            )
//                            faceCroppedListener!!.response(
//                                """
//                                 {
//                                 "refId" : "${deviceId}",
//                                 "collection_name": "indian-bank",
//                                 "recordId": "string",
//                                 "image": "${originalImage}"
//                                }
////                            """.trimIndent(), originalImage, false
//                            )

                            if (SDKConfig.isAttandance && SDKConfig.isFaceRegistration) {

                                HttpRequestHelper.validateData(
                                    baseURL = SDKConfig.baseURL,
                                    name = SDKConfig.userData?.name ?: "",
                                    organisation = SDKConfig.userData?.organisation ?: "",
                                    email = SDKConfig.userData?.email ?: "",
                                    phoneNumber = SDKConfig.userData?.phoneNumber ?: "",
                                    uid = SDKConfig.userData?.uid ?: "",
                                    image = originalImage ?: ""
                                ) { message, status ->
                                    CoroutineScope(Dispatchers.Main).launch {
                                        if (status) {
                                            Log.d("Validation", "Validation Success: $message")
                                            faceCameraView?.binding?.progressView?.visibility = android.view.View.GONE
                                            faceCroppedListener?.onFaceRegistered(message, originalImage ?: "")
                                        } else {
                                            Log.e("Validation", "Validation Failed: $message")
                                        }
                                    }
                                }
                            }
                            else if (SDKConfig.isFaceMatch) {
                                NetworkCall.isCalled = true

                                val face1 = originalImage ?: ""
                                val face2 = SDKConfig.referenceImage

                                Log.d("FACE_MATCH", "========== FACE MATCH ==========")
                                Log.d("FACE_MATCH", "Face1 length: ${face1.length}")
                                Log.d("FACE_MATCH", "Face1 start: ${face1.take(50)}")
                                Log.d("FACE_MATCH", "Face1 end: ${face1.takeLast(50)}")

                                Log.d("FACE_MATCH", "Face2 length: ${face2.length}")
                                Log.d("FACE_MATCH", "Face2 start: ${face2.take(50)}")
                                Log.d("FACE_MATCH", "Face2 end: ${face2.takeLast(50)}")
                                Log.d("FACE_MATCH", "Face2 empty: ${face2.isEmpty()}")

                                HttpRequestHelper.faceMatch(
                                    face1 = face1,
                                    face2 = face2,
                                    callback = { message, isMatch ->

                                        CoroutineScope(Dispatchers.Main).launch {

                                            Log.d("FACE_MATCH", "========== RESULT ==========")
                                            Log.d("FACE_MATCH", "Message: $message")
                                            Log.d("FACE_MATCH", "Is Match: $isMatch")

                                            faceCameraView?.binding?.progressView?.visibility =
                                                View.GONE

                                            faceCroppedListener?.onFaceDetected(
                                                message,
                                                face1,
                                                isMatch
                                            )
                                        }
                                    }
                                )
                            }
                            else {
                                FaceProcess.getHttpResponse(
                                    faceCameraView!!,
                                    faceCroppedListener!!,
                                    context,
                                    originalImage ?: "",
                                    originalImage,
                                    frameImage
                                )
                            }
                        } else {
                            Log.e("FaceDetector Count", HitCount.faceNetworkCallHit.toString())
                            NetworkCall.isCalled = false
                            HitCount.isFaceDetected = false
                            HitCount.isProcessing = false
                            NetworkCall.isSpoofCalled = false
                        }
                    } else {
//                        HitCount.isProcessing = false
                        HitCount.faceNetworkCallHit = 0
                        HitCount.isFaceDetected = true
                        NetworkCall.isCalled = true
                        faceCameraView?.binding?.progressView?.visibility = android.view.View.GONE
                        val originalImage = BitmapUtils.BitmaptoBase64(frameImage)
                        originalImage?.let {
                            faceCroppedListener!!.onSpoofDetected(
                                "Liveness Check Failed", originalImage
                            )
                            Log.e("Spoof", "Given Image Spoof Detected")
                        }
                    }
                }

                return@withContext FaceSpoofResult(
                    isSpoof = iSpoof,
                    score = score,
                    timeMillis = time
                )
            }
        }

    private fun isFaceFrontal(landmarks: List<NormalizedLandmark>): Boolean {
        val leftEye = landmarks[33]
        val rightEye = landmarks[263]
        val noseTip = landmarks[1]

        val eyeLevelDiff = kotlin.math.abs(leftEye.y() - rightEye.y())
        val midEyeX = (leftEye.x() + rightEye.x()) / 2
        val noseCenterOffset = kotlin.math.abs(noseTip.x() - midEyeX)

        return eyeLevelDiff < 0.02 && noseCenterOffset < 0.02
    }
    fun cropHeadAligned(
        bitmap: Bitmap,
        landmarks: List<NormalizedLandmark>
    ): Bitmap? {

        val leftEye = landmarks[33]
        val rightEye = landmarks[263]

        val dx = rightEye.x() - leftEye.x()
        val dy = rightEye.y() - leftEye.y()

        val angle = Math.toDegrees(kotlin.math.atan2(dy.toDouble(), dx.toDouble())).toFloat()

        val matrix = Matrix()
        matrix.postRotate(-angle)

        val rotated = Bitmap.createBitmap(
            bitmap,
            0,
            0,
            bitmap.width,
            bitmap.height,
            matrix,
            true
        )

        return cropHeadOnly(rotated, landmarks)
    }

    fun cropHeadOnly(
        bitmap: Bitmap,
        landmarks: List<NormalizedLandmark>
    ): Bitmap? {
        if (landmarks.isEmpty()) return null

        val imageWidth = bitmap.width
        val imageHeight = bitmap.height

        // Face bounding box from landmarks
        val xs = landmarks.map { it.x() * imageWidth }
        val ys = landmarks.map { it.y() * imageHeight }

        val faceLeft = xs.minOrNull() ?: return null
        val faceRight = xs.maxOrNull() ?: return null
        val faceTop = ys.minOrNull() ?: return null
        val faceBottom = ys.maxOrNull() ?: return null

        val faceWidth = faceRight - faceLeft
        val faceHeight = faceBottom - faceTop

        // Padding tuned for HEAD ONLY
        val topPadding = faceHeight * 0.40f    // hair
        val sidePadding = faceWidth * 0.30f    // ears
        val bottomPadding = faceHeight * 0.10f // just chin safety

        val cropLeft = (faceLeft - sidePadding).toInt().coerceAtLeast(0)
        val cropTop = (faceTop - topPadding).toInt().coerceAtLeast(0)
        val cropRight = (faceRight + sidePadding).toInt().coerceAtMost(imageWidth)
        val cropBottom = (faceBottom + bottomPadding).toInt().coerceAtMost(imageHeight)

        val cropWidth = cropRight - cropLeft
        val cropHeight = cropBottom - cropTop

        if (cropWidth <= 0 || cropHeight <= 0) return null

        return Bitmap.createBitmap(
            bitmap,
            cropLeft,
            cropTop,
            cropWidth,
            cropHeight
        )
    }

    fun resizePreserveAspect(
        bitmap: Bitmap,
        targetWidth: Int,
        targetHeight: Int
    ): Bitmap {
        val scale = minOf(
            targetWidth.toFloat() / bitmap.width,
            targetHeight.toFloat() / bitmap.height
        )

        val newWidth = (bitmap.width * scale).toInt()
        val newHeight = (bitmap.height * scale).toInt()

        val scaled = Bitmap.createScaledBitmap(bitmap, newWidth, newHeight, true)

        // Center pad to exact size (passport safe)
        val output = Bitmap.createBitmap(
            targetWidth,
            targetHeight,
            Bitmap.Config.ARGB_8888
        )

        val canvas = Canvas(output)
        canvas.drawColor(Color.BLACK) // or WHITE
        val left = (targetWidth - newWidth) / 2f
        val top = (targetHeight - newHeight) / 2f
        canvas.drawBitmap(scaled, left, top, null)

        return output
    }

    private fun softMax(x: FloatArray): FloatArray {
        val exp = x.map { exp(it) }
        val expSum = exp.sum()
        return exp.map { it / expSum }.toFloatArray()
    }

    private fun crop(
        origImage: Bitmap,
        bbox: Rect,
        bboxScale: Float,
        targetWidth: Int,
        targetHeight: Int
    ): Bitmap {
        val srcWidth = origImage.width
        val srcHeight = origImage.height
        val scaledBox = getScaledBox(srcWidth, srcHeight, bbox, bboxScale)
        val croppedBitmap =
            Bitmap.createBitmap(
                origImage,
                scaledBox.left,
                scaledBox.top,
                scaledBox.width(),
                scaledBox.height()
            )
        return Bitmap.createScaledBitmap(croppedBitmap, targetWidth, targetHeight, true)
    }

    private fun safeCrop(
        origImage: Bitmap,
        bbox: Rect,
        bboxScale: Float,
        targetWidth: Int,
        targetHeight: Int
    ): Bitmap {
        val srcWidth = origImage.width
        val srcHeight = origImage.height
        val scaledBox = getScaledBox(srcWidth, srcHeight, bbox, bboxScale)

        val safeBox = Rect(
            scaledBox.left.coerceIn(0, srcWidth - 1),
            scaledBox.top.coerceIn(0, srcHeight - 1),
            scaledBox.right.coerceIn(0, srcWidth),
            scaledBox.bottom.coerceIn(0, srcHeight)
        )

        // Width and height must be > 0
        val width = (safeBox.width()).coerceAtLeast(1)
        val height = (safeBox.height()).coerceAtLeast(1)

        val cropped = Bitmap.createBitmap(origImage, safeBox.left, safeBox.top, width, height)
        return Bitmap.createScaledBitmap(cropped, targetWidth, targetHeight, true)
    }


    private fun getScaledBox(srcWidth: Int, srcHeight: Int, box: Rect, bboxScale: Float): Rect {
        val x = box.left
        val y = box.top
        val w = box.width()
        val h = box.height()
        val scale = floatArrayOf((srcHeight - 1f) / h, (srcWidth - 1f) / w, bboxScale).min()
        val newWidth = w * scale
        val newHeight = h * scale
        val centerX = w / 2 + x
        val centerY = h / 2 + y
        var topLeftX = centerX - newWidth / 2
        var topLeftY = centerY - newHeight / 2
        var bottomRightX = centerX + newWidth / 2
        var bottomRightY = centerY + newHeight / 2
        if (topLeftX < 0) {
            bottomRightX -= topLeftX
            topLeftX = 0f
        }
        if (topLeftY < 0) {
            bottomRightY -= topLeftY
            topLeftY = 0f
        }
        if (bottomRightX > srcWidth - 1) {
            topLeftX -= (bottomRightX - (srcWidth - 1))
            bottomRightX = (srcWidth - 1).toFloat()
        }
        if (bottomRightY > srcHeight - 1) {
            topLeftY -= (bottomRightY - (srcHeight - 1))
            bottomRightY = (srcHeight - 1).toFloat()
        }
        return Rect(topLeftX.toInt(), topLeftY.toInt(), bottomRightX.toInt(), bottomRightY.toInt())
    }

    

//    override fun onEmptyDetect() {
//        HitCount.isProcessing = false
//    }
//
//    override suspend fun onDetect(
//        boundingBoxes: List<BoundingBox>,
//        inferenceTime: Long,
//        rotatedBitmap: Bitmap,
//        rect: Rect,
//        originalImage: String,
//        context: Context
//    ) {
//        for (boundingBox in boundingBoxes) {
//            try {
//                when (boundingBox.clsName) {
//                    "real" -> {
//                        if (boundingBox.cnf >= 0.7f) {
//                            val deviceId = Settings.Secure.getString(context.contentResolver, Settings.Secure.ANDROID_ID)
//                            faceCroppedListener!!.response("""
//                                 {
//                                 "refId" : "${deviceId}",
//                                 "collection_name": "indian-bank",
//                                 "recordId": "string",
//                                 "image": "${originalImage}"
//                                }
//                            """.trimIndent(), originalImage)
//                        }
//                    }
//                    "fake" -> {
//                        if (boundingBox.cnf >= 0.4) {
//                            HitCount.isProcessing = false
//                        }
//                    }
//                    else -> {
//
//                    }
//                }
//            } catch (e: Exception) {
//                Log.e("onDetect", "Error processing bounding box: ${e.message}")
//                break
//            }
//        }
//
//    }
}
