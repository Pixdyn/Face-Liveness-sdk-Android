package com.pixl.facesearch.Model

import android.annotation.SuppressLint
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel

class DataViewModel : ViewModel() {
    companion object {
        private val _imgBase64 = MutableLiveData<String>()
        private val _baseURL = MutableLiveData<String>()

        @SuppressLint("NullSafeMutableLiveData")
        fun resetAllValues() {
            _imgBase64.value = null
            _baseURL.value = null
        }

        val imageBase64: LiveData<String>
            get() = _imgBase64

        fun setImageBase64(cache: String) {
            _imgBase64.value = cache
        }

        val baseURL: LiveData<String>
            get() = _baseURL

        fun setBaseurl(baseurl: String) {
            _baseURL.value = baseurl
        }

    }
}