package com.pixl.facesearch.FaceAndSpoofDetector

import kotlinx.coroutines.flow.MutableSharedFlow

object FaceQualityBus {
    val events = MutableSharedFlow<FaceQualityIssue>(
        replay = 0,
        extraBufferCapacity = 1
    )
}
