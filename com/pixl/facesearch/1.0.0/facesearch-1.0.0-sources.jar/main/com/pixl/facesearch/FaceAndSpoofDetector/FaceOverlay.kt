//package com.example.faceapp
//
//import android.content.Context
//import android.graphics.*
//import android.util.AttributeSet
//import android.view.View
//
//class OverlayView @JvmOverloads constructor(
//    context: Context, attrs: AttributeSet? = null
//) : View(context, attrs) {
//
//    private val boxPaint = Paint().apply {
//        color = Color.GREEN
//        style = Paint.Style.STROKE
//        strokeWidth = 5f
//    }
//
//    private val textPaint = Paint().apply {
//        color = Color.RED
//        textSize = 50f
//    }
//
//    private var boxes: List<RectF> = emptyList()
//    private var imageWidth = 0
//    private var imageHeight = 0
//    private var message: String = ""
//
//    fun updateBoxes(newBoxes: List<RectF>, imageWidth: Int, imageHeight: Int){
//        this.boxes = newBoxes
//        this.imageWidth = imageWidth
//        this.imageHeight = imageHeight
//        invalidate()
//    }
//
//    fun setMessage(message: String) {
//        this.message = message
//        invalidate()
//    }
//
//    override fun onDraw(canvas: Canvas) {
//        super.onDraw(canvas)
//        boxes.forEach { box ->
//            canvas.drawRect(box, boxPaint)
//        }
//        if (message.isNotEmpty()) {
//            canvas.drawText(message, 50f, 100f, textPaint)
//        }
//    }
//}



package com.pixl.facesearch.FaceAndSpoofDetector

import android.content.Context
import android.graphics.*
import android.util.AttributeSet
import android.view.View
import com.pixl.facesearch.Model.Prediction

class FaceOverlayView @JvmOverloads constructor(
    context: Context, attrs: AttributeSet? = null
) : View(context, attrs) {

    private val boxPaint = Paint().apply {
        color = Color.parseColor("#4D90caf9")
        style = Paint.Style.STROKE
        strokeWidth = 5f
    }

    private val textPaint = Paint().apply {
        color = Color.WHITE
        textSize = 40f
        style = Paint.Style.FILL
    }

    var predictions: List<Prediction> = emptyList()

    fun updatePredictions(newPredictions: List<Prediction>) {
        predictions = newPredictions
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        predictions.forEach {
            canvas.drawRoundRect(it.bbox, 12f, 12f, boxPaint)
            canvas.drawText(it.label, it.bbox.left, it.bbox.top - 10, textPaint)
        }
    }
}
