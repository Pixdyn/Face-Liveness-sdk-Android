package com.pixl.facesearch.CameraAndFace

import android.annotation.SuppressLint
import android.app.AlertDialog
import android.content.Context
import android.graphics.*
import android.media.Image
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.Handler
import android.os.Looper
import android.speech.tts.TextToSpeech
import android.util.Log
import android.view.View
import android.widget.Toast
import androidx.camera.core.*
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import androidx.core.graphics.alpha
import androidx.core.graphics.blue
import androidx.lifecycle.LifecycleOwner
import com.pixl.facesearch.FaceAndSpoofDetector.FaceSpoofDetector
import com.pixl.facesearch.FaceAndSpoofDetector.ImageVectorUseCase
import com.pixl.facesearch.Model.FaceToastViewModel
import com.pixl.facesearch.Utils.HitCount
import com.pixl.facesearch.databinding.ActivityFaceBinding
import com.google.mediapipe.tasks.components.containers.NormalizedLandmark
import com.google.mediapipe.tasks.core.BaseOptions
import com.google.mediapipe.tasks.vision.core.RunningMode
import com.google.mediapipe.tasks.vision.facelandmarker.FaceLandmarker
import com.pixl.facesearch.FaceAndSpoofDetector.FaceQualityBus
import com.pixl.facesearch.FaceAndSpoofDetector.FaceQualityIssue
import kotlinx.coroutines.*
import java.io.ByteArrayOutputStream
import java.util.concurrent.ExecutorService
import kotlin.math.abs

enum class FaceHintState {
    NONE,
    MOVE_CLOSER,
    MOVE_BACK,
    LOOK_STRAIGHT,
    HOLD_STILL,
    FACE_DETECTING,

    MULTIPLE_FACE_DETECTING,
    LOW_LIGHT,
    TOO_BRIGHT
}

class FaceAnalyzer(
    private val context: Context,
    private val previewView: PreviewView,
    private val faceSpoofDetector: FaceSpoofDetector,
    private val imageVectorUseCase: ImageVectorUseCase,
    private val cameraOverlaysView: CameraOverlaysView,
    private val faceHintViewModel: FaceToastViewModel,
    private val faceCameraView: FaceCameraView
)  {

    private lateinit var faceLandmarker: FaceLandmarker
    private lateinit var binding: ActivityFaceBinding
    private var currentToast: Toast? = null

    private lateinit var tts: TextToSpeech
    var isTTSInitialized = false
    private var speakQueue: MutableList<String> = mutableListOf()
    private var alertDialog: AlertDialog? = null

    private val frameBuffer = ArrayDeque<Bitmap>(10)

    // Variable to store the last known position of the nose
    private var lastNosePosition: NormalizedLandmark? = null

    private var currentFaceHintState: FaceHintState = FaceHintState.NONE

    @Volatile
    private var latestLandmarks: List<NormalizedLandmark>? = null

    var faceProgressValue = 0;

    private var lastStableLandmarks: List<NormalizedLandmark>? = null
    private var unstableFrameCount = 0

    private val MAX_MOVEMENT_THRESHOLD = 0.015f
    private val MAX_UNSTABLE_FRAMES = 5

    private var lastHintTime = 0L
    private val HINT_DELAY = 2000L

    @Volatile
    private var isMultipleFaceDetected = false


    init {
        setupLandmarker()
    }

    fun speak(text: String) {
        if (isTTSInitialized) {
            tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "speech_done")
        } else {
            speakQueue.add(text)
        }
    }

    private fun setupLandmarker() {
        val baseOptions = BaseOptions.builder()
            .setModelAssetPath("face_landmarker.task")
            .build()

        val options = FaceLandmarker.FaceLandmarkerOptions.builder()
            .setBaseOptions(baseOptions)
            .setRunningMode(RunningMode.IMAGE)
            .setNumFaces(5)
            .setMinFaceDetectionConfidence(0.5f)
            .setMinTrackingConfidence(0.5f)
            .setMinFacePresenceConfidence(0.5f)
            .build()

        faceLandmarker = FaceLandmarker.createFromOptions(context, options)
    }

    @SuppressLint("UnsafeOptInUsageError")
    fun startCamera(context: Context, cameraExecutor: ExecutorService) {
        val cameraProviderFuture = ProcessCameraProvider.getInstance(context)

        cameraProviderFuture.addListener({
            val cameraProvider = cameraProviderFuture.get()

            val preview = Preview.Builder().build().also {
                it.setSurfaceProvider(previewView.surfaceProvider)
            }

            val imageAnalyzer = ImageAnalysis.Builder()
                .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                .build()

            imageAnalyzer.setAnalyzer(cameraExecutor, object : ImageAnalysis.Analyzer {
                override fun analyze(imageProxy: ImageProxy) {
                    if (HitCount.isProcessing) {
                        frameBuffer.clear()
                        imageProxy.close()
                        return
                    }
                    val mediaImage = imageProxy.image ?: run {
                        imageProxy.close()
                        return
                    }

                    if (NetworkCall.isCalled) {
                        imageProxy.close()
                        return
                    }

                    val rotationDegrees = imageProxy.imageInfo.rotationDegrees
                    val bitmap = toBitmap(mediaImage)
                    val rotatedBitmap = Bitmap.createBitmap(
                        bitmap, 0, 0, bitmap.width, bitmap.height,
                        Matrix().apply { postRotate(rotationDegrees.toFloat()) },
                        true
                    )
                    val mpImage =
                        com.google.mediapipe.framework.image.BitmapImageBuilder(rotatedBitmap)
                            .build()
                    val result = faceLandmarker.detect(mpImage)

                    // --- Determine the new hint state ---
                    val newHintState: FaceHintState
                    val hintMessage: String

                    // 1. Check for multiple faces immediately
                    val validFaces = result.faceLandmarks().filter { landmarks ->
                        val xs = landmarks.map { it.x() }
                        val ys = landmarks.map { it.y() }

                        val width = (xs.maxOrNull() ?: 0f) - (xs.minOrNull() ?: 0f)
                        val height = (ys.maxOrNull() ?: 0f) - (ys.minOrNull() ?: 0f)

                        width > 0.12f && height > 0.12f
                    }

                    if (validFaces.size > 1) {
                        isMultipleFaceDetected = true

                        synchronized(frameBuffer) {
                            frameBuffer.clear()
                        }

                        latestLandmarks = null
                        HitCount.isProcessing = false

                        val multiFaceState = FaceHintState.MULTIPLE_FACE_DETECTING
                        val multiFaceMessage =
                            "Multiple faces detected"

                        updateFaceHintState(multiFaceState, multiFaceMessage)
                        HitCount.resetValues()

                        Log.w("FaceDetection", "Process rejected: ${result.faceLandmarks().size} faces found.")

                        imageProxy.close()
                        return
                    } else {
                        isMultipleFaceDetected = false
                    }
                    if (result.faceLandmarks().isEmpty()) {
                        newHintState = FaceHintState.NONE
                        hintMessage = ""
                        lastNosePosition = null
                        faceProgressValue = 0
                        faceCameraView.binding.cameralayout.setProgress(0f)
                    } else {
                        if (faceProgressValue < 25) {
                            faceProgressValue = 25
                            faceCameraView.binding.cameralayout.setProgress(faceProgressValue.toFloat())
                        }

                        if (validFaces.isEmpty()) {
                            imageProxy.close()
                            return
                        }

                        latestLandmarks = validFaces[0]
                        val landmarks = validFaces[0]
                        val noseTip = landmarks[1]
                        val lastPos = lastNosePosition
                        lastNosePosition = noseTip

                        val isDark=isFaceTooDarkLuminance(rotatedBitmap, landmarks)
                        if (isDark) {
                            newHintState=FaceHintState.LOW_LIGHT
                            hintMessage="Lighting too low. Face light source"
                            updateFaceHintState(newHintState, hintMessage)
                            imageProxy.close()
                            return
                        } else {
//                            updateFaceHintState(FaceHintState.NONE, "")
                        }

                        // Skip small or partial faces
                        if (landmarks.size <= 460 || !isFaceFrontal(landmarks)) {
                            FaceQualityBus.events.tryEmit(FaceQualityIssue.NONE)
                            imageProxy.close()
                            return
                        }

                        val isSteady = lastStableLandmarks?.let {
                            isFaceSteady(landmarks, it)
                        } ?: true

                        lastStableLandmarks = landmarks

                        if (!isSteady || !isFaceFrontal(landmarks)) {
                            unstableFrameCount++

                            if (unstableFrameCount >= MAX_UNSTABLE_FRAMES) {
                                updateFaceHintState(
                                    FaceHintState.LOOK_STRAIGHT,
                                    "Please look straight and hold still"
                                )
                                imageProxy.close()
                                return
                            }
                        } else {
                            unstableFrameCount = 0
                        }

                        if (!isFullFaceVisible(
                                landmarks,
                                rotatedBitmap.width,
                                rotatedBitmap.height
                            )
                        ) {
                            newHintState = FaceHintState.MOVE_CLOSER
                            hintMessage = "Please come closer to the camera"
                            updateFaceHintState(newHintState, hintMessage)
                            imageProxy.close()
                            return
                        }

                        val distanceInCm =
                            estimateDistanceFromLandmarks(landmarks, rotatedBitmap.width)
                        when {
                            distanceInCm < 40 -> {
                                newHintState = FaceHintState.MOVE_BACK
                                hintMessage = "Please move slightly back"
                                updateFaceHintState(newHintState, hintMessage)
                                imageProxy.close()
                                return
                            }

                            distanceInCm > 70 -> {
                                newHintState = FaceHintState.MOVE_CLOSER
                                hintMessage = "Please come closer to the camera"
                                updateFaceHintState(newHintState, hintMessage)
                                imageProxy.close()
                                return
                            }

                            else -> {
                                newHintState = FaceHintState.NONE
                                hintMessage = ""
                            }
                        }
                    }
                    updateFaceHintState(newHintState, hintMessage)
                    if (result.faceLandmarks().isNotEmpty()) {
                        val distanceInCm = estimateDistanceFromLandmarks(
                            result.faceLandmarks()[0],
                            rotatedBitmap.width
                        )
                        if (distanceInCm >= 40) { //distanceInCm in 30f..40f
                            synchronized(frameBuffer) {
                                frameBuffer.add(rotatedBitmap.copy(rotatedBitmap.config!!, false))
                                Log.d("FRAME_DEBUG", "Frame added to buffer. Buffer size: ${frameBuffer.size}")
                            }
                            Log.d("FRAME_DEBUG", "Processing started. Frames collected: ${frameBuffer.size}")
                            if (frameBuffer.size >= 5 && !NetworkCall.isCalled && !isMultipleFaceDetected) {

                                val framesToAnalyze = ArrayList(frameBuffer)
                                frameBuffer.clear()

                                CoroutineScope(Dispatchers.Default).launch {


                                    if (!HitCount.isProcessing && !isMultipleFaceDetected) {

                                        HitCount.isProcessing = true
                                        latestLandmarks?.let { lm ->

                                            when {
                                                isMultipleFaceDetected -> {
                                                    updateFaceHintState(
                                                        FaceHintState.MULTIPLE_FACE_DETECTING,
                                                        "Multiple faces detected"
                                                    )
                                                    HitCount.isProcessing = false
                                                }

                                                !isFaceSteadyEnough(lm) -> {
                                                    updateFaceHintState(
                                                        FaceHintState.HOLD_STILL,
                                                        "Please hold still"
                                                    )
                                                    HitCount.isProcessing = false
                                                }

                                                !isFaceFrontal(lm) -> {
                                                    updateFaceHintState(
                                                        FaceHintState.LOOK_STRAIGHT,
                                                        "Please look straight"
                                                    )
                                                    HitCount.isProcessing = false
                                                }

                                                else -> {
                                                    val bestFrame = getBestFrame(framesToAnalyze, lm)

//                                                    if (calculateSharpness(bestFrame) < 25) {
//                                                        updateFaceHintState(
//                                                            FaceHintState.HOLD_STILL,
//                                                            "Image blurry, hold still"
//                                                        )
//                                                        HitCount.isProcessing = false
//                                                        return@let
//                                                    }
                                                    Log.d("FRAME_DEBUG", "Frame sent for recognition")
                                                    analyzeFrameBatch(listOf(bestFrame), lm)
                                                }
                                            }
                                        } ?: run {
                                            updateFaceHintState(
                                                FaceHintState.NONE,
                                                "Face not detected"
                                            )
                                            HitCount.isProcessing = false
                                        }
                                    }

//                                    if (!HitCount.isProcessing && !isMultipleFaceDetected) {
//
//                                        HitCount.isProcessing = true
//
//                                        delay(300)
//
//                                        latestLandmarks?.let { lm ->
//
//                                            if (!isMultipleFaceDetected && isFaceSteadyEnough(lm)) {
//                                                val bestFrame = getBestFrame(framesToAnalyze, lm)
//                                                analyzeFrameBatch(listOf(bestFrame), lm)
//                                            } else {
//                                                HitCount.isProcessing = false
//                                            }
//                                        }
//                                    }
                                }
                            }

//                            if (frameBuffer.size >= 10 && !NetworkCall.isCalled && !isMultipleFaceDetected) {
//                                val framesToAnalyze = ArrayList(frameBuffer)
//                                val bestFrame = getBestFrame(framesToAnalyze, latestLandmarks ?: emptyList())
//                                frameBuffer.clear()
//
//                                CoroutineScope(Dispatchers.Default).launch {
//                                    if (!HitCount.isProcessing && !isMultipleFaceDetected) {
//                                        HitCount.isProcessing = true
//
//                                        latestLandmarks?.let { lm ->
//                                            if (!isMultipleFaceDetected) {
//                                                analyzeFrameBatch(listOf(bestFrame), lm)
//                                            }
//                                        }
//                                    }
//                                }
////                                CoroutineScope(Dispatchers.Default).launch {
////                                    if (!HitCount.isProcessing) {
////                                        HitCount.isProcessing = true
//////                                        delay(500)
////                                        latestLandmarks?.let { lm ->
////                                            if (!isMultipleFaceDetected) {
////                                                analyzeFrameBatch(framesToAnalyze, lm)
////                                            }
////                                        }
//////                                        analyzeFrameBatch(framesToAnalyze)
////                                    }
////                                }
//                            }
                        }
                    } else {
                        FaceQualityBus.events.tryEmit(FaceQualityIssue.NONE)
                    }

                    imageProxy.close()
                }
            })

            cameraProvider.unbindAll()
            cameraProvider.bindToLifecycle(
                context as LifecycleOwner,
                CameraSelector.DEFAULT_FRONT_CAMERA,
                preview,
                imageAnalyzer
            )
        }, ContextCompat.getMainExecutor(context))
    }

    private fun isFaceTooDarkLuminance(bitmap: Bitmap, landmarks: List<NormalizedLandmark>): Boolean {
        val rect = getLandmarkBoundingBox(
            landmarks.toMutableList(),
            bitmap.width,
            bitmap.height
        )

        if (rect.width() <= 0 || rect.height() <= 0) return true

        val safeLeft = rect.left.coerceAtLeast(0)
        val safeTop = rect.top.coerceAtLeast(0)
        val safeWidth = rect.width().coerceAtMost(bitmap.width - safeLeft)
        val safeHeight = rect.height().coerceAtMost(bitmap.height - safeTop)

        val faceBitmap = Bitmap.createBitmap(
            bitmap,
            safeLeft,
            safeTop,
            safeWidth,
            safeHeight
        )

        var totalLuminance = 0.0
        var pixelCount = 0

        for (x in 0 until faceBitmap.width step 8) {
            for (y in 0 until faceBitmap.height step 8) {
                val pixel = faceBitmap.getPixel(x, y)

                val r = Color.red(pixel)
                val g = Color.green(pixel)
                val b = Color.blue(pixel)

                val luminance = (0.299 * r + 0.587 * g + 0.114 * b)

                totalLuminance += luminance
                pixelCount++
            }
        }

        val avgLuminance = totalLuminance / pixelCount

        Log.d("FaceLuminance", "Average luminance = $avgLuminance")

        return avgLuminance < 65
    }
    private fun isFaceSteadyEnough(
        landmarks: List<NormalizedLandmark>
    ): Boolean {
        val previous = lastStableLandmarks ?: return true
        return isFaceSteady(landmarks, previous)
    }
    private fun isFaceSteady(
        current: List<NormalizedLandmark>,
        previous: List<NormalizedLandmark>
    ): Boolean {
        val currNose = current[1]
        val prevNose = previous[1]

        val dx = kotlin.math.abs(currNose.x() - prevNose.x())
        val dy = kotlin.math.abs(currNose.y() - prevNose.y())

        return dx < MAX_MOVEMENT_THRESHOLD && dy < MAX_MOVEMENT_THRESHOLD
    }

    private fun updateFaceHintState(newState: FaceHintState, message: String) {

        val now = System.currentTimeMillis()

        // prevent repeating same hint
        if (currentFaceHintState == newState && now - lastHintTime < HINT_DELAY) {
            return
        }

        currentFaceHintState = newState
        lastHintTime = now

        Handler(Looper.getMainLooper()).post {

            if (newState == FaceHintState.NONE) {
                faceHintViewModel.hideHint()
                return@post
            }

            faceHintViewModel.setFaceHintText(message)
            faceHintViewModel.showHint()

            when (newState) {

                FaceHintState.MOVE_CLOSER -> {
                    faceHintViewModel.setFaceHintColor(Color.YELLOW)
                    faceCameraView.binding.cameralayout
                        .setBorderState(CameraOverlaysView.BorderState.COME_CLOSE)
                }

                FaceHintState.MOVE_BACK -> {
                    faceHintViewModel.setFaceHintColor(Color.YELLOW)
                    faceCameraView.binding.cameralayout
                        .setBorderState(CameraOverlaysView.BorderState.COME_CLOSE)
                }

                FaceHintState.LOOK_STRAIGHT -> {
                    faceHintViewModel.setFaceHintColor(Color.GREEN)
                    faceCameraView.binding.cameralayout
                        .setBorderState(CameraOverlaysView.BorderState.LOOK_STRAIGHT)
                }

                FaceHintState.MULTIPLE_FACE_DETECTING -> {
                    faceHintViewModel.setFaceHintColor(Color.RED)
                    faceCameraView.binding.cameralayout
                        .setBorderState(CameraOverlaysView.BorderState.MULTIPLE_FACE_DETECT)
                }

                FaceHintState.LOW_LIGHT -> {
                    faceHintViewModel.setFaceHintColor(Color.YELLOW)
                }

                FaceHintState.TOO_BRIGHT -> {
                    faceHintViewModel.setFaceHintColor(Color.RED)
                    faceCameraView.binding.cameralayout
                        .setBorderState(CameraOverlaysView.BorderState.TOO_BRIGHT)
                }

                else -> {}
            }
        }
    }

    private fun calculateBrightness(bitmap: Bitmap): Double {
        var sum = 0L
        val width = bitmap.width
        val height = bitmap.height

        val pixels = IntArray(width * height)
        bitmap.getPixels(pixels, 0, width, 0, 0, width, height)

        for (pixel in pixels) {
            val r = Color.red(pixel)
            val g = Color.green(pixel)
            val b = Color.blue(pixel)

            // Luminance formula
            val luminance = (0.299 * r + 0.587 * g + 0.114 * b).toInt()
            sum += luminance
        }

        return sum.toDouble() / pixels.size
    }


    private fun isFullFaceVisible(
        landmarks: List<NormalizedLandmark>,
        imageWidth: Int,
        imageHeight: Int
    ): Boolean {
        val boundingBox = getLandmarkBoundingBox(landmarks.toMutableList(), imageWidth, imageHeight)

        val margin = 5 // relaxed from 10
        val minBoxWidth = imageWidth * 0.3 // relaxed from 0.4
        val minBoxHeight = imageHeight * 0.3

        val isInsideEdges = boundingBox.left > margin &&
                boundingBox.top > margin &&
                boundingBox.right < imageWidth - margin &&
                boundingBox.bottom < imageHeight - margin

        val isReasonableSize = boundingBox.width() > minBoxWidth &&
                boundingBox.height() > minBoxHeight

        Log.d(
            "FaceBoundingBox",
            "Box: $boundingBox, isInsideEdges: $isInsideEdges, isReasonableSize: $isReasonableSize"
        )

        return isInsideEdges && isReasonableSize
    }

    private suspend fun analyzeFrameBatch(
        frames: List<Bitmap>,
        landmarks: List<NormalizedLandmark>
    ) {
        try {
//            if (!isInternetAvailable(context)) {
//                withContext(Dispatchers.Main) {
//                    showNoInternetDialog()
//                }
//                return
//            }

            val results = withContext(Dispatchers.IO) {

                frames.map { frame ->
                    async {
                        imageVectorUseCase.getNearestPersonName(
                            context,
                            listOf(frame),
                            landmarks,
                            cameraOverlaysView
                        )
                    }
                }.awaitAll()
            }

            val nameMatches = results.map { it.second }
            val mostCommon = nameMatches.groupingBy { it }.eachCount().maxByOrNull { it.value }?.key

        } catch (e: Exception) {
            Log.e("BatchProcessing", "Error analyzing frames: ${e.message}")
        }
    }

    fun isInternetAvailable(context: Context): Boolean {
        val connectivityManager =
            context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val network = connectivityManager.activeNetwork ?: return false
        val networkCapabilities =
            connectivityManager.getNetworkCapabilities(network) ?: return false
        return networkCapabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
    }

    private var isAlertDialogVisible = false

    private fun showNoInternetDialog() {
        if (isAlertDialogVisible) return

        isAlertDialogVisible = true

        AlertDialog.Builder(context)
            .setTitle("No Internet Connection")
            .setMessage("Please check your internet connection and try again.")
            .setCancelable(false)
            .setPositiveButton("OK") { dialog, _ ->
                dialog.dismiss()
                isAlertDialogVisible = false
            }
            .setOnDismissListener {
                isAlertDialogVisible = false
            }
            .show()
    }

    private fun getBestFrame(
        frames: List<Bitmap>,
        landmarks: List<NormalizedLandmark>
    ): Bitmap {
        return frames.maxByOrNull { frame ->
            calculateSharpness(frame)
        } ?: frames.first()
    }

    private fun calculateSharpness(bitmap: Bitmap): Double {
        var sharpness = 0.0

        for (x in 1 until bitmap.width - 1 step 4) {
            for (y in 1 until bitmap.height - 1 step 4) {
                val c1 = Color.red(bitmap.getPixel(x, y))
                val c2 = Color.red(bitmap.getPixel(x + 1, y))
                sharpness += kotlin.math.abs(c1 - c2)
            }
        }

        return sharpness
    }

    private fun isFaceFrontal(landmarks: List<NormalizedLandmark>): Boolean {
        val leftEye = landmarks[33]
        val rightEye = landmarks[263]
        val noseTip = landmarks[1]

        val eyeLevelDiff = abs(leftEye.y() - rightEye.y())
        val midEyeX = (leftEye.x() + rightEye.x()) / 2
        val noseCenterOffset = abs(noseTip.x() - midEyeX)

        val isEyeAligned = eyeLevelDiff < 0.02
        val isNoseCentered = noseCenterOffset < 0.02

        return isEyeAligned && isNoseCentered
    }

    private fun getLandmarkBoundingBox(
        landmarks: MutableList<NormalizedLandmark>,
        imageWidth: Int,
        imageHeight: Int
    ): Rect {
        val xs = landmarks.map { it.x() * imageWidth }
        val ys = landmarks.map { it.y() * imageHeight }

        val left = xs.minOrNull()?.toInt() ?: 0
        val top = ys.minOrNull()?.toInt() ?: 0
        val right = xs.maxOrNull()?.toInt() ?: 0
        val bottom = ys.maxOrNull()?.toInt() ?: 0

        return Rect(left, top, right, bottom)
    }

//    private fun toBitmap(image: Image): Bitmap {
//        val yBuffer = image.planes[0].buffer
//        val uBuffer = image.planes[1].buffer
//        val vBuffer = image.planes[2].buffer
//
//        val ySize = yBuffer.remaining()
//        val uSize = uBuffer.remaining()
//        val vSize = vBuffer.remaining()
//
//        val nv21 = ByteArray(ySize + uSize + vSize)
//        yBuffer.get(nv21, 0, ySize)
//        vBuffer.get(nv21, ySize, vSize)
//        uBuffer.get(nv21, ySize + vSize, uSize)
//
//
//        val yuvImage = YuvImage(nv21, ImageFormat.NV21, image.width, image.height, null)
//        val out = ByteArrayOutputStream()
//        yuvImage.compressToJpeg(Rect(0, 0, image.width, image.height), 90, out)
//        return BitmapFactory.decodeByteArray(out.toByteArray(), 0, out.size())
//    }
    private fun toBitmap(image: Image): Bitmap {
        val nv21 = yuv420888ToNv21(image)
        val yuvImage = YuvImage(nv21, ImageFormat.NV21, image.width, image.height, null)
        val out = ByteArrayOutputStream()
        yuvImage.compressToJpeg(Rect(0, 0, image.width, image.height), 90, out)
        return BitmapFactory.decodeByteArray(out.toByteArray(), 0, out.size())
    }

    private fun yuv420888ToNv21(image: Image): ByteArray {
        val width = image.width
        val height = image.height
        val ySize = width * height
        val uvSize = width * height / 2
        val output = ByteArray(ySize + uvSize)

        val yPlane = image.planes[0]
        val uPlane = image.planes[1]
        val vPlane = image.planes[2]

        val yBuffer = yPlane.buffer
        val uBuffer = uPlane.buffer
        val vBuffer = vPlane.buffer

        val yRowStride = yPlane.rowStride
        val yPixelStride = yPlane.pixelStride
        var outIndex = 0

        for (row in 0 until height) {
            val rowStart = row * yRowStride
            for (col in 0 until width) {
                val index = rowStart + col * yPixelStride
                output[outIndex++] = yBuffer.get(index)
            }
        }

        val uvRowStride = uPlane.rowStride
        val uvPixelStride = uPlane.pixelStride
        val chromaHeight = height / 2
        val chromaWidth = width / 2

        for (row in 0 until chromaHeight) {
            val rowStart = row * uvRowStride
            for (col in 0 until chromaWidth) {
                val index = rowStart + col * uvPixelStride
                // NV21 expects interleaved VU bytes.
                output[outIndex++] = vBuffer.get(index)
                output[outIndex++] = uBuffer.get(index)
            }
        }

        return output
    }

    private fun estimateDistanceFromLandmarks(
        landmarks: List<NormalizedLandmark>,
        imageWidth: Int
    ): Double {
        val leftEye = landmarks[33] // Approx. left eye
        val rightEye = landmarks[263] // Approx. right eye

        val dx = (leftEye.x() - rightEye.x()) * imageWidth
        val distanceInPixels = abs(dx)

        // Average inter-ocular distance (IOD) ~6.3 cm in adults
        // Focal length (example, varies by device) = 870
        val focalLength = 870.0
        val realIOD = 6.3 // cm

        return (realIOD * focalLength) / distanceInPixels
    }

    private fun showToast(message: String) {
        Handler(Looper.getMainLooper()).post {

            if (currentToast != null) return@post

            currentToast = Toast.makeText(context, message, Toast.LENGTH_SHORT)
            currentToast?.show()

            Handler(Looper.getMainLooper()).postDelayed({
                currentToast = null
            }, 2000)
        }
    }

    private fun cancelToast() {
        Handler(Looper.getMainLooper()).post {
            currentToast?.cancel()
            currentToast = null
        }
    }
}