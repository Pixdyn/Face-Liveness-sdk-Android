package com.pixl.facesearch.FaceAndSpoofDetector

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Rect
import com.google.mediapipe.tasks.components.containers.NormalizedLandmark
import com.pixl.facesearch.CameraAndFace.CameraOverlaysView
import com.pixl.facesearch.CameraAndFace.NetworkCall
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.withContext
import kotlin.math.pow
import kotlin.math.sqrt
import kotlin.time.DurationUnit
import kotlin.time.measureTimedValue

data class RecognitionMetrics(
    val timeFaceDetection: Long,
    val timeVectorSearch: Long,
    val timeFaceEmbedding: Long,
    val timeFaceSpoofDetection: Long
)

class ImageVectorUseCase(
    private val mediapipeFaceDetector: MediapipeFaceDetector,
    private val faceSpoofDetector: FaceSpoofDetector
) {

    data class FaceRecognitionResult(
        val personName: String,
        val boundingBox: Rect,
        val spoofResult: FaceSpoofDetector.FaceSpoofResult? = null
    )
    suspend fun getNearestPersonName(
        context: Context,
        frameBitmaps: List<Bitmap>,
        landmarks: List<NormalizedLandmark>,
        cameraOverlaysView: CameraOverlaysView
    ): Pair<RecognitionMetrics?, List<FaceRecognitionResult>> {
        // Reset network calls for a fresh session
        NetworkCall.isCalled = false
        NetworkCall.isSpoofCalled = false

        val mutableFrames = frameBitmaps.toMutableList()
        if (mutableFrames.isEmpty()) return Pair(null, emptyList())

        val (faceDetectionResult, t1) = measureTimedValue {
            withContext(Dispatchers.IO) {
                mutableFrames.map { frame ->
                    async { mediapipeFaceDetector.getAllCroppedFaces(frame) }
                }.awaitAll().flatten()
            }
        }

        val faceRecognitionResults = ArrayList<FaceRecognitionResult>()
        var avgT4 = 0L

        for ((_, boundingBox) in faceDetectionResult) {
            var totalSpoofTime = 0L
            var selectedSpoofResult: FaceSpoofDetector.FaceSpoofResult? = null

            for (frame in mutableFrames) {
                val spoofResult = faceSpoofDetector.detectSpoof(context, frame, boundingBox, landmarks, cameraOverlayView = cameraOverlaysView)
                totalSpoofTime += spoofResult.timeMillis
                if (!spoofResult.isSpoof && selectedSpoofResult == null) {
                    selectedSpoofResult = spoofResult
                }
            }

            avgT4 += totalSpoofTime / mutableFrames.size
            faceRecognitionResults.add(
                FaceRecognitionResult(
                    personName = "",
                    boundingBox = boundingBox,
                    spoofResult = selectedSpoofResult
                )
            )
        }

        val metrics =
            if (faceDetectionResult.isNotEmpty()) {
                RecognitionMetrics(
                    timeFaceDetection = t1.toLong(DurationUnit.MILLISECONDS),
                    timeFaceEmbedding = 0,
                    timeVectorSearch = 0,
                    timeFaceSpoofDetection = avgT4 / faceDetectionResult.size
                )
            } else {
                null
            }

        return Pair(metrics, faceRecognitionResults)
    }


    private fun cosineDistance(x1: FloatArray, x2: FloatArray): Float {
        var mag1 = 0.0f
        var mag2 = 0.0f
        var product = 0.0f
        for (i in x1.indices) {
            mag1 += x1[i].pow(2)
            mag2 += x2[i].pow(2)
            product += x1[i] * x2[i]
        }
        mag1 = sqrt(mag1)
        mag2 = sqrt(mag2)
        return product / (mag1 * mag2)
    }

}
