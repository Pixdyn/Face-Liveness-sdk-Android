package com.pixl.facesearch.CameraAndFace

import android.animation.ValueAnimator
import android.content.Context
import android.content.res.Configuration
import android.graphics.*
import android.os.Looper
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.View
import android.view.animation.DecelerateInterpolator
import android.view.animation.LinearInterpolator
import androidx.annotation.FloatRange
import com.pixl.facesearch.R

class CameraOverlaysView @JvmOverloads constructor(
    context: Context, attrs: AttributeSet? = null
) : View(context, attrs) {

    enum class BorderState {
        DEFAULT,
        FACE_DETECTING,
        FACE_DETECTED,
        FACE_FAILED,
        BLINK_DETECTED,
        COME_CLOSE,
        LOOK_STRAIGHT,
        MULTIPLE_FACE_DETECT,
        LOW_LIGHT,
        TOO_BRIGHT
    }

    // 1. Dark Background (Reduced Opacity from 90% #E6 to 60% #99)
    private val overlayPaint = Paint().apply {
        color = Color.WHITE
        style = Paint.Style.FILL
    }

    // 2. Transparent Hole Cutter
    private val transparentPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.TRANSPARENT
        xfermode = PorterDuffXfermode(PorterDuff.Mode.CLEAR)
    }

    // 3. Standard Blue Border (Base)
    private val cornerPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#1A82E2")
        style = Paint.Style.STROKE
        strokeWidth = 0f
    }

    // 4. UPDATED: Progress Border (Increased width)
    private val progressPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#1A82E2")
        style = Paint.Style.STROKE
        strokeWidth = 18f
        strokeCap = Paint.Cap.ROUND
    }

    // 5. Loader for "Searching" state
    private val loaderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#1A82E2")
        style = Paint.Style.STROKE
        strokeWidth = 10f
        strokeCap = Paint.Cap.ROUND
    }

    private val scanLinePaint = Paint()
    private var scanAnimator: ValueAnimator? = null
    private var loaderAnimator: ValueAnimator? = null

    // Animation Tracker
    private var progressAnimator: ValueAnimator? = null

    private var scanLineY: Float = 0f
    private var progressAngle: Float = 0f
    private var currentProgressPercent: Float = 0f

    private var isScanning = false
    private val cutoutRect = RectF()
    private var borderState = BorderState.DEFAULT

    // --- Back Button Variables ---
    private var backIcon: Bitmap? = null
    private val backRect = RectF()
    var onBackClick: (() -> Unit)? = null

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)

        // Detect orientation
        val isLandscape = resources.configuration.orientation == Configuration.ORIENTATION_LANDSCAPE

        val overlayWidth: Float
        val overlayHeight: Float

        if (isLandscape) {
            // Landscape mode: use height as base, make oval narrower
            overlayHeight = h * 0.7f
            overlayWidth = overlayHeight * 0.75f  // Narrower oval for landscape
        } else {
            // Portrait mode: use width as base, make oval taller
            overlayWidth = w * 0.8f
            overlayHeight = overlayWidth * 1.2f
        }

        val centerX = w / 2f
        val centerY = h / 2f

        val left = centerX - overlayWidth / 2
        val top = centerY - overlayHeight / 2
        val right = centerX + overlayWidth / 2
        val bottom = centerY + overlayHeight / 2
        cutoutRect.set(left, top, right, bottom)

        // --- Back Button Initialization ---
        try {
            // Get the drawable and mutate it so changes don't affect other parts of the app
            val drawable = resources.getDrawable(R.drawable.ic_arrow_back, null).mutate()
            // CHANGED: Set the tint to WHITE here
            drawable.setTint(Color.WHITE)

            val bitmap = Bitmap.createBitmap(80, 80, Bitmap.Config.ARGB_8888)
            val canvasBmp = Canvas(bitmap)
            drawable.setBounds(0, 0, 80, 80)
            drawable.draw(canvasBmp)
            backIcon = bitmap
        } catch (e: Exception) {
            e.printStackTrace()
        }

        // Set position for back button (Top Left)
        backRect.set(40f, 40f, 120f, 120f)

        // Scan line shader setup
        val scanLineColor = Color.parseColor("#1A82E2")
        scanLinePaint.shader = LinearGradient(
            cutoutRect.left, 0f, cutoutRect.right, 0f,
            intArrayOf(Color.TRANSPARENT, scanLineColor, Color.TRANSPARENT),
            floatArrayOf(0f, 0.5f, 1f),
            Shader.TileMode.CLAMP
        )
    }

    // Handles Animation: Ease-Out up, Snap down
    fun setProgress(@FloatRange(from = 0.0, to = 100.0) percent: Float) {
        if (Looper.myLooper() != Looper.getMainLooper()) {
            post { setProgress(percent) }
            return
        }

        progressAnimator?.cancel()

        if (percent > currentProgressPercent) {
            progressAnimator = ValueAnimator.ofFloat(currentProgressPercent, percent).apply {
                duration = 300
                interpolator = DecelerateInterpolator()
                addUpdateListener { animation ->
                    currentProgressPercent = animation.animatedValue as Float
                    invalidate()
                }
                start()
            }
        } else {
            currentProgressPercent = percent
            invalidate()
        }
    }

    fun setBorderState(state: BorderState) {
        borderState = state
        when (state) {
            BorderState.FACE_DETECTING -> startLoaderAnimation()
            BorderState.FACE_DETECTED, BorderState.FACE_FAILED -> stopLoaderAnimation()
            else -> { /* ignore */ }
        }
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val density = resources.displayMetrics.density

        // 1. Draw Background Layer
        val layerId = canvas.saveLayer(0f, 0f, width.toFloat(), height.toFloat(), null)

        // Draw the dark translucent background
        canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), overlayPaint)

        // --- Draw Back Button (Now White) ---
        backIcon?.let {
            canvas.drawBitmap(it, null, backRect, null)
        }

        // Cut the hole (Transparent Oval)
        canvas.drawOval(cutoutRect, transparentPaint)

        canvas.restoreToCount(layerId)

        // 2. Draw Scanner Line
        if (isScanning) {
            canvas.save()
            val path = Path().apply { addOval(cutoutRect, Path.Direction.CW) }
            canvas.clipPath(path)
            val scanLineHeight = 10f * density
            canvas.drawRect(
                cutoutRect.left,
                scanLineY,
                cutoutRect.right,
                scanLineY + scanLineHeight,
                scanLinePaint
            )
            canvas.restore()
        }

        // 3. Draw Base Border
        drawBaseBorder(canvas)

        // 4. Draw Progress Arc (Blue)
        if (currentProgressPercent > 0) {
            val sweepAngle = 360f * (currentProgressPercent / 100f)
            canvas.drawArc(cutoutRect, -90f, sweepAngle, false, progressPaint)
        }
    }

    private fun drawBaseBorder(canvas: Canvas) {
        when (borderState) {
            BorderState.DEFAULT -> {
                cornerPaint.color = Color.parseColor("#ADD8E6")
                canvas.drawOval(cutoutRect, cornerPaint)
            }
            BorderState.FACE_DETECTING -> {
                cornerPaint.color = Color.parseColor("#66B2FF")
                canvas.drawOval(cutoutRect, cornerPaint)
                val inset = 8f
                val arcRect = RectF(
                    cutoutRect.left + inset,
                    cutoutRect.top + inset,
                    cutoutRect.right - inset,
                    cutoutRect.bottom - inset
                )
                canvas.drawArc(arcRect, progressAngle, 90f, false, loaderPaint)
            }
            BorderState.FACE_DETECTED -> {
                cornerPaint.color = Color.parseColor("#337ab7")
                canvas.drawOval(cutoutRect, cornerPaint)
            }
            BorderState.FACE_FAILED -> {
                cornerPaint.color = Color.RED
                canvas.drawOval(cutoutRect, cornerPaint)
            }
            else -> {
                cornerPaint.color = Color.parseColor("#337ab7")
                canvas.drawOval(cutoutRect, cornerPaint)
            }
        }
    }

    // --- Touch Event for Back Button ---
    override fun onTouchEvent(event: MotionEvent): Boolean {
        // Expand hit area slightly for better UX
        val expandedRect = RectF(
            backRect.left - 40,
            backRect.top - 40,
            backRect.right + 40,
            backRect.bottom + 40
        )

        when (event.action) {
            MotionEvent.ACTION_UP -> {
                if (expandedRect.contains(event.x, event.y)) {
                    performClick()
                    onBackClick?.invoke()
                    return true
                }
            }
            // Add ACTION_DOWN to consume the event so ACTION_UP can be triggered
            MotionEvent.ACTION_DOWN -> {
                if (expandedRect.contains(event.x, event.y)) {
                    return true
                }
            }
        }
        // Return true to consume all touches on this overlay.
        return true
    }

    override fun performClick(): Boolean {
        super.performClick()
        return true
    }

    private fun startLoaderAnimation() {
        stopLoaderAnimation()
        loaderAnimator = ValueAnimator.ofFloat(0f, 360f).apply {
            duration = 1500L
            interpolator = LinearInterpolator()
            repeatCount = ValueAnimator.INFINITE
            addUpdateListener { anim ->
                progressAngle = anim.animatedValue as Float
                invalidate()
            }
            start()
        }
    }

    private fun stopLoaderAnimation() {
        loaderAnimator?.cancel()
        loaderAnimator = null
        progressAngle = 0f
        invalidate()
    }

    fun setScanning(scanning: Boolean) {
        if (Looper.myLooper() != Looper.getMainLooper()) {
            post { setScanning(scanning) }
            return
        }
        isScanning = scanning
        if (isScanning) startScanAnimation() else stopScanAnimation()
    }

    private fun startScanAnimation() {
        if (scanAnimator?.isRunning == true || cutoutRect.isEmpty) return
        scanAnimator = ValueAnimator.ofFloat(cutoutRect.top, cutoutRect.bottom).apply {
            duration = 2500L
            repeatMode = ValueAnimator.REVERSE
            repeatCount = ValueAnimator.INFINITE
            addUpdateListener {
                scanLineY = it.animatedValue as Float
                invalidate()
            }
            start()
        }
    }

    private fun stopScanAnimation() {
        scanAnimator?.cancel()
        scanAnimator = null
        invalidate()
    }
}