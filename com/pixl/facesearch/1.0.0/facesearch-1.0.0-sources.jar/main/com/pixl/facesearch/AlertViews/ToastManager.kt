package com.pixl.facesearch.AlertViews

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.widget.Toast

object ToastManager {
    private val toastQueue: ArrayDeque<String> = ArrayDeque()
    private var currentToast: Toast? = null
    private var isShowing = false
    private val handler = Handler(Looper.getMainLooper())

    fun showToast(context: Context, message: String) {
        handler.post {
//            toastQueue.addLast(message)
            if (!isShowing) {
                showNextToast(context, message)
            }
        }
    }

    private fun showNextToast(context: Context, message: String) {
//        if (toastQueue.isEmpty()) {
//            isShowing = false
//            return
//        }

//        val message = toastQueue.removeFirst()
        currentToast = Toast.makeText(context, message, Toast.LENGTH_SHORT)
        currentToast?.show()
        isShowing = true

        handler.postDelayed({
            currentToast = null
//            showNextToast(context, message)
        }, 1000)
    }

    fun clearAllToasts() {
        handler.post {
//            toastQueue.clear()
            currentToast?.cancel()
            currentToast = null
            isShowing = false
        }
    }
}
