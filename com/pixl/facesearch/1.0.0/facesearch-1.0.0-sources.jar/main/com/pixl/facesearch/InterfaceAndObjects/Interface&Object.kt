package com.pixl.facesearch.InterfaceAndObjects

import android.graphics.Bitmap

interface SuccessResponse {
    fun resultResponse(response: String)
}

object SuccessResponseListenerSingleton {
    var listener: SuccessResponse? = null
}

//interface ResponseListener {
//    fun onResponseReceived(response: String, image: String)
//    fun cancel()
//    fun newUserResponse(image: String, name: String, email: String, phoneNumber: String, organization: String)
//}

//object ResponseListenerSingleton {
//    var listener: ResponseListener? = null
//}

interface FaceCroppedListener {

    fun onFaceRegistered(response: String, image: String)
    fun onSpoofDetected(response: String, image: String)

    fun onFaceDetected(response: String, image: String, isFaceMatching: Boolean)
//    fun response(response: String, image: String?, isSpoof: Boolean)
    fun startFaceSearch()
    fun newUserData(image: String, name: String, email: String, phoneNumber: String, organization: String)
    fun finishActivity()
}