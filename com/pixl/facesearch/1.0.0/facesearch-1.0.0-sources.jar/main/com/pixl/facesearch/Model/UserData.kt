package com.pixl.facesearch.Model

data class UserData(
    val name: String,
    val mobile: String,
    val organization: String,
    val email: String
)
